export type PermissionKey = string;

export type AuthorizationSubject = Readonly<{
  /** Stable authenticated subject identifier. */
  id: string;
  /** Canonical permission keys granted to the subject for the current request context. */
  permissions: ReadonlySet<PermissionKey>;
}>;

export type AuthorizationDecision = Readonly<{
  allowed: boolean;
  permission: PermissionKey;
  subjectId: string;
  reason: 'granted' | 'missing-permission';
}>;

export class AuthorizationDeniedError extends Error {
  readonly code = 'AUTHORIZATION_DENIED' as const;
  readonly permission: PermissionKey;
  readonly subjectId: string;

  constructor(subjectId: string, permission: PermissionKey) {
    super(`Subject ${subjectId} is not authorized for ${permission}.`);
    this.name = 'AuthorizationDeniedError';
    this.subjectId = subjectId;
    this.permission = permission;
  }
}

export function evaluatePermission(
  subject: AuthorizationSubject,
  permission: PermissionKey,
): AuthorizationDecision {
  const allowed = subject.permissions.has(permission);
  return Object.freeze({
    allowed,
    permission,
    subjectId: subject.id,
    reason: allowed ? 'granted' : 'missing-permission',
  });
}

export function requirePermission(
  subject: AuthorizationSubject,
  permission: PermissionKey,
): void {
  const decision = evaluatePermission(subject, permission);
  if (!decision.allowed) {
    throw new AuthorizationDeniedError(subject.id, permission);
  }
}
