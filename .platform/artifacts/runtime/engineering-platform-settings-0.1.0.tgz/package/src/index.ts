export const SETTING_SCOPES = [
  'platform',
  'project',
  'environment',
  'tenant',
  'user',
  'emergency',
] as const;

export type SettingScope = (typeof SETTING_SCOPES)[number];

export type SettingResolution =
  | 'OVERRIDE'
  | 'REPLACE'
  | 'MERGE'
  | 'FLOOR'
  | 'CEILING'
  | 'STRONGEST'
  | 'FLAG_EVALUATION'
  | 'NO_OVERRIDE';

export type SettingValueType =
  | 'boolean'
  | 'integer'
  | 'number'
  | 'string'
  | 'enum'
  | 'duration'
  | 'money'
  | 'array'
  | 'object';

export type SettingDefinition<T> = Readonly<{
  key: string;
  valueType: SettingValueType;
  resolution: SettingResolution;
  scopes: readonly SettingScope[];
  /** Required for OVERRIDE/REPLACE. Ordered from lowest to highest authority. */
  precedence?: readonly SettingScope[];
  default: T;
  minimum?: number;
  maximum?: number;
  enumValues?: readonly T[];
  sensitive?: boolean;
}>;

export type ScopedSettingValue<T> = Readonly<{
  value: T;
  version?: number;
  source?: string;
}>;

export type SettingValues<T> = Partial<Record<SettingScope, ScopedSettingValue<T>>>;

export type SettingResolutionTrace<T> = Readonly<{
  key: string;
  value: T;
  resolution: SettingResolution;
  winner: Readonly<{
    scope: SettingScope | 'default';
    source: string;
    version?: number;
  }>;
  considered: readonly Readonly<{
    scope: SettingScope;
    populated: boolean;
    value?: T;
    source?: string;
    version?: number;
  }>[];
}>;

export class SettingsResolutionError extends Error {
  readonly code: 'SETTING_DEFINITION_INVALID' | 'SETTING_SCOPE_FORBIDDEN' | 'SETTING_VALUE_INVALID' | 'SETTING_RESOLUTION_UNSUPPORTED';
  readonly key: string;

  constructor(
    code: SettingsResolutionError['code'],
    key: string,
    message: string,
  ) {
    super(message);
    this.name = 'SettingsResolutionError';
    this.code = code;
    this.key = key;
  }
}

export function resolveSetting<T>(
  definition: SettingDefinition<T>,
  values: SettingValues<T> = {},
): SettingResolutionTrace<T> {
  validateDefinition(definition);
  validateProvidedScopes(definition, values);

  const considered = definition.scopes.map((scope) => {
    const entry = values[scope];
    if (entry) validateValue(definition, entry.value, scope);
    return Object.freeze({
      scope,
      populated: Boolean(entry),
      ...(entry ? { value: entry.value, source: entry.source ?? scope, version: entry.version } : {}),
    });
  });

  if (definition.resolution === 'NO_OVERRIDE') {
    const platform = values.platform;
    const value = platform ? platform.value : definition.default;
    validateValue(definition, value, platform ? 'platform' : 'default');
    return Object.freeze({
      key: definition.key,
      value,
      resolution: definition.resolution,
      winner: Object.freeze(
        platform
          ? { scope: 'platform' as const, source: platform.source ?? 'platform', version: platform.version }
          : { scope: 'default' as const, source: 'registry-default' },
      ),
      considered: Object.freeze(considered),
    });
  }

  if (definition.resolution !== 'OVERRIDE') {
    throw new SettingsResolutionError(
      'SETTING_RESOLUTION_UNSUPPORTED',
      definition.key,
      `Resolution policy ${definition.resolution} is not implemented in settings 0.1.0.`,
    );
  }

  const precedence = definition.precedence!;
  for (let index = precedence.length - 1; index >= 0; index -= 1) {
    const scope = precedence[index];
    const entry = values[scope];
    if (!entry) continue;
    return Object.freeze({
      key: definition.key,
      value: entry.value,
      resolution: definition.resolution,
      winner: Object.freeze({
        scope,
        source: entry.source ?? scope,
        version: entry.version,
      }),
      considered: Object.freeze(considered),
    });
  }

  validateValue(definition, definition.default, 'default');
  return Object.freeze({
    key: definition.key,
    value: definition.default,
    resolution: definition.resolution,
    winner: Object.freeze({ scope: 'default' as const, source: 'registry-default' }),
    considered: Object.freeze(considered),
  });
}

export function resolveSettingValue<T>(
  definition: SettingDefinition<T>,
  values: SettingValues<T> = {},
): T {
  return resolveSetting(definition, values).value;
}

export function explainSetting<T>(
  definition: SettingDefinition<T>,
  values: SettingValues<T> = {},
): SettingResolutionTrace<T> {
  return resolveSetting(definition, values);
}

function validateDefinition<T>(definition: SettingDefinition<T>): void {
  if (!definition.key.trim()) {
    invalidDefinition(definition, 'Setting key must not be empty.');
  }
  if (definition.scopes.length === 0 || new Set(definition.scopes).size !== definition.scopes.length) {
    invalidDefinition(definition, 'Setting scopes must be non-empty and unique.');
  }

  if (definition.resolution === 'OVERRIDE' || definition.resolution === 'REPLACE') {
    const precedence = definition.precedence;
    if (!precedence || precedence.length !== definition.scopes.length) {
      invalidDefinition(definition, `${definition.resolution} requires explicit precedence covering every allowed scope.`);
    }
    if (new Set(precedence).size !== precedence.length) {
      invalidDefinition(definition, 'Setting precedence must not contain duplicate scopes.');
    }
    const allowed = new Set(definition.scopes);
    if (precedence.some((scope) => !allowed.has(scope)) || definition.scopes.some((scope) => !precedence.includes(scope))) {
      invalidDefinition(definition, 'Setting precedence must contain exactly the allowed scopes.');
    }
  } else if (definition.precedence && definition.precedence.length > 0) {
    invalidDefinition(definition, `Precedence is only valid for OVERRIDE/REPLACE in settings 0.1.0.`);
  }

  if (definition.resolution === 'NO_OVERRIDE') {
    if (definition.scopes.length !== 1 || definition.scopes[0] !== 'platform') {
      invalidDefinition(definition, 'NO_OVERRIDE settings must be platform-only.');
    }
  }

  validateValue(definition, definition.default, 'default');
}

function validateProvidedScopes<T>(definition: SettingDefinition<T>, values: SettingValues<T>): void {
  const allowed = new Set(definition.scopes);
  for (const scope of SETTING_SCOPES) {
    if (values[scope] !== undefined && !allowed.has(scope)) {
      throw new SettingsResolutionError(
        'SETTING_SCOPE_FORBIDDEN',
        definition.key,
        `Scope ${scope} is not allowed for ${definition.key}.`,
      );
    }
  }
}

function validateValue<T>(definition: SettingDefinition<T>, value: T, source: SettingScope | 'default'): void {
  let validType = true;
  switch (definition.valueType) {
    case 'integer':
      validType = typeof value === 'number' && Number.isSafeInteger(value);
      break;
    case 'number':
      validType = typeof value === 'number' && Number.isFinite(value);
      break;
    case 'boolean':
      validType = typeof value === 'boolean';
      break;
    case 'string':
    case 'enum':
    case 'duration':
      validType = typeof value === 'string';
      break;
    case 'array':
      validType = Array.isArray(value);
      break;
    case 'object':
    case 'money':
      validType = typeof value === 'object' && value !== null && !Array.isArray(value);
      break;
  }
  if (!validType) {
    invalidValue(definition, source, `Expected ${definition.valueType}.`);
  }

  if ((definition.valueType === 'integer' || definition.valueType === 'number') && typeof value === 'number') {
    if (definition.minimum !== undefined && value < definition.minimum) {
      invalidValue(definition, source, `Value ${value} is below minimum ${definition.minimum}.`);
    }
    if (definition.maximum !== undefined && value > definition.maximum) {
      invalidValue(definition, source, `Value ${value} is above maximum ${definition.maximum}.`);
    }
  }

  if (definition.valueType === 'enum' && definition.enumValues && !definition.enumValues.includes(value)) {
    invalidValue(definition, source, `Value is not one of the declared enum values.`);
  }
}

function invalidDefinition<T>(definition: SettingDefinition<T>, message: string): never {
  throw new SettingsResolutionError('SETTING_DEFINITION_INVALID', definition.key, message);
}

function invalidValue<T>(definition: SettingDefinition<T>, source: SettingScope | 'default', message: string): never {
  throw new SettingsResolutionError(
    'SETTING_VALUE_INVALID',
    definition.key,
    `Invalid value from ${source}: ${message}`,
  );
}
