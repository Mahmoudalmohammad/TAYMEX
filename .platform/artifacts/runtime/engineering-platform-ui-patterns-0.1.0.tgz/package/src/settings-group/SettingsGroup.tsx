import type { ReactNode } from 'react';
export interface SettingsGroupProps { id:string; title:string; description?:string; children:ReactNode; }
export function SettingsGroup({id,title,description,children}:SettingsGroupProps){const heading=`${id}-heading`;return <section data-ep-ui-pattern="settings-group" data-ep-settings-group aria-labelledby={heading}><header><h2 id={heading}>{title}</h2>{description?<p>{description}</p>:null}</header><div data-settings-controls>{children}</div></section>}
