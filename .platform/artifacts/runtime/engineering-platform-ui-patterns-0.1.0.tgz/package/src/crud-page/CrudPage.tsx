import type { ReactNode } from 'react';
import { PageHeader } from '@engineering-platform/ui';
export interface CrudPageProps { title:string; description?:string; actions?:ReactNode; summary?:ReactNode; filters?:ReactNode; content:ReactNode; pagination?:ReactNode; }
export function CrudPage({title,description,actions,summary,filters,content,pagination}:CrudPageProps){return <section data-ep-ui-pattern="crud-page"><PageHeader title={title} description={description} actions={actions}/>{summary}{filters?<div data-ep-crud-filters>{filters}</div>:null}<div data-crud-content>{content}</div>{pagination?<div data-ep-crud-pagination>{pagination}</div>:null}</section>}
