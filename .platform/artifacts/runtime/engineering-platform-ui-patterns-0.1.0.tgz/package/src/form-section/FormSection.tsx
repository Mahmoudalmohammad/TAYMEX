import type { ReactNode } from 'react';
export interface FormSectionProps { id:string; title:string; description?:string; actions?:ReactNode; children:ReactNode; }
export function FormSection({id,title,description,actions,children}:FormSectionProps){const heading=`${id}-heading`;return <section data-ep-ui-pattern="form-section" data-ep-form-section aria-labelledby={heading}><header><div><h2 id={heading}>{title}</h2>{description?<p>{description}</p>:null}</div>{actions}</header><div data-form-section-fields>{children}</div></section>}
