import type { ReactNode } from 'react';
export interface FilterPanelProps { title:string; children:ReactNode; actions?:ReactNode; resultSummary?:ReactNode; }
export function FilterPanel({title,children,actions,resultSummary}:FilterPanelProps){return <section data-ep-ui-pattern="filter-panel" aria-label={title}><header><h2>{title}</h2>{resultSummary}</header><div data-filter-controls>{children}</div>{actions?<footer data-filter-actions>{actions}</footer>:null}</section>}
