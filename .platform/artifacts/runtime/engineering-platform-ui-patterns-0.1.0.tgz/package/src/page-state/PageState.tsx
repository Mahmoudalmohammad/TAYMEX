import type { ReactNode } from 'react';
export type PageStateKind = 'loading' | 'empty' | 'partial' | 'error' | 'success' | 'offline' | 'permission-denied' | 'rate-limited';
export interface PageStateProps { kind: PageStateKind; title: string; description?: string; action?: ReactNode; }
export function PageState({kind,title,description,action}:PageStateProps){return <section data-ep-ui-pattern="page-state" data-state={kind} aria-live={kind==='error'?'assertive':'polite'}><h2>{title}</h2>{description?<p>{description}</p>:null}{action}</section>}
