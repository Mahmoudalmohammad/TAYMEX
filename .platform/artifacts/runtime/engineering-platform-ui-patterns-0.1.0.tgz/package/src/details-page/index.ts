export * from './DetailsPage';
