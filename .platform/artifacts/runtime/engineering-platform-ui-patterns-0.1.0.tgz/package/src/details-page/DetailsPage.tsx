import type { ReactNode } from 'react';
import { PageHeader } from '@engineering-platform/ui';
export interface DetailsPageProps { title:string; subtitle?:string; actions?:ReactNode; summary?:ReactNode; status?:ReactNode; children:ReactNode; }
export function DetailsPage({title,subtitle,actions,summary,status,children}:DetailsPageProps){return <section data-ep-ui-pattern="details-page"><PageHeader title={title} description={subtitle} actions={actions}/>{status}{summary}<div data-ep-details-content>{children}</div></section>}
