import type { ReactNode } from 'react';
export interface DataToolbarProps { search?:ReactNode; filters?:ReactNode; actions?:ReactNode; selectionActions?:ReactNode; }
export function DataToolbar({search,filters,actions,selectionActions}:DataToolbarProps){return <div data-ep-ui-pattern="data-toolbar">{selectionActions?<div data-toolbar-selection>{selectionActions}</div>:null}<div data-toolbar-search>{search}</div><div data-toolbar-filters>{filters}</div><div data-toolbar-actions>{actions}</div></div>}
