import type { ReactNode } from 'react';
import { PageHeader } from '@engineering-platform/ui';
export interface FormPageProps { title:string; description?:string; actions?:ReactNode; status?:ReactNode; children:ReactNode; }
export function FormPage({title,description,actions,status,children}:FormPageProps){return <section data-ep-ui-pattern="form-page"><PageHeader title={title} description={description} actions={actions}/>{status}<div data-ep-form-grid>{children}</div></section>}
