import type { ReactNode } from 'react';
import { PageHeader } from '@engineering-platform/ui';
export interface SettingsPageProps { title:string; description?:string; search?:ReactNode; navigation?:ReactNode; children:ReactNode; actions?:ReactNode; status?:ReactNode; }
export function SettingsPage({title,description,search,navigation,children,actions,status}:SettingsPageProps){return <section data-ep-ui-pattern="settings-page"><PageHeader title={title} description={description} actions={actions}/>{status}{search?<div data-ep-settings-search>{search}</div>:null}<div data-ep-settings-layout>{navigation?<aside data-ep-settings-navigation>{navigation}</aside>:null}<div data-ep-settings-content>{children}</div></div></section>}
