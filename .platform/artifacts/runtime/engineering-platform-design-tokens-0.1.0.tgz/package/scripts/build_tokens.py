from __future__ import annotations
from pathlib import Path
import argparse, json, re, sys

ROOT = Path(__file__).resolve().parents[1]
TOKEN_DIR = ROOT / "tokens"
DIST = ROOT / "dist"
REF = re.compile(r"^\{([A-Za-z0-9_.-]+)\}$")


def flatten(node, prefix="", inherited_type=None):
    out = {}
    if not isinstance(node, dict):
        return out
    own_type = node.get("$type", inherited_type)
    for key, value in node.items():
        if key.startswith("$"):
            continue
        path = f"{prefix}.{key}" if prefix else key
        if isinstance(value, dict) and "$value" in value:
            out[path] = {"value": value["$value"], "type": value.get("$type", own_type)}
        elif isinstance(value, dict):
            out.update(flatten(value, path, value.get("$type", own_type)))
    return out


def load(name):
    return json.loads((TOKEN_DIR / name).read_text(encoding="utf-8"))


def resolve_value(key, tokens, stack=None):
    stack = list(stack or [])
    if key in stack:
        raise ValueError("Circular token alias: " + " -> ".join(stack + [key]))
    if key not in tokens:
        raise ValueError(f"Unknown token alias: {key}")
    value = tokens[key]["value"]
    if isinstance(value, str):
        m = REF.match(value)
        if m:
            return resolve_value(m.group(1), tokens, stack + [key])
        return value
    if isinstance(value, dict) and set(value) >= {"value", "unit"}:
        return f"{value['value']}{value['unit']}"
    if isinstance(value, list):
        return ", ".join(value)
    return str(value)


def css_name(key):
    return "--ep-" + re.sub(r"[^a-z0-9-]+", "-", key.lower().replace(".", "-"))


def hex_rgb(value):
    if not isinstance(value, str) or not re.fullmatch(r"#[0-9A-Fa-f]{6}", value):
        return None
    return tuple(int(value[i:i+2], 16)/255 for i in (1,3,5))


def luminance(rgb):
    vals=[]
    for c in rgb:
        vals.append(c/12.92 if c <= .04045 else ((c+.055)/1.055)**2.4)
    return .2126*vals[0] + .7152*vals[1] + .0722*vals[2]


def contrast(a,b):
    ra, rb = hex_rgb(a), hex_rgb(b)
    if not ra or not rb:
        return None
    la, lb = luminance(ra), luminance(rb)
    lighter, darker = max(la,lb), min(la,lb)
    return (lighter+.05)/(darker+.05)


def panda_theme(core_resolved, light_resolved, dark_resolved):
    # DTCG remains source of truth. Panda receives a generated, framework-specific projection.
    def val(key): return core_resolved[key]
    tokens = {
        "spacing": {k.split(".")[-1]: {"value": v} for k,v in core_resolved.items() if k.startswith("space.")},
        "radii": {k.split(".")[-1]: {"value": v} for k,v in core_resolved.items() if k.startswith("radius.")},
        "sizes": {k.split(".")[-1]: {"value": v} for k,v in core_resolved.items() if k.startswith("size.")},
        "fontSizes": {k.split(".")[-1]: {"value": v} for k,v in core_resolved.items() if k.startswith("font.size.")},
        "fontWeights": {k.split(".")[-1]: {"value": v} for k,v in core_resolved.items() if k.startswith("font.weight.")},
        "fonts": {"sans": {"value": core_resolved.get("font.family.sans")}},
        "durations": {k.split(".")[-1]: {"value": v} for k,v in core_resolved.items() if k.startswith("motion.duration.")},
    }
    semantic = {}
    for key, light in light_resolved.items():
        if not key.startswith("semantic.color."):
            continue
        path = key.removeprefix("semantic.color.").split(".")
        node=semantic
        for part in path[:-1]: node=node.setdefault(part,{})
        dark=dark_resolved.get(key,light)
        node[path[-1]]={"value":{"base":light,"_dark":dark}}
    return {"tokens":tokens,"semanticTokens":{"colors":semantic}}


def build(check=False):
    core = flatten(load("core.tokens.json"))
    themes={}
    for theme in ("light","dark"):
        themed=dict(core)
        themed.update(flatten(load(f"{theme}.tokens.json")))
        # Resolve every token so broken aliases fail the build.
        resolved={k: resolve_value(k,themed) for k in themed}
        themes[theme]=resolved

    required_pairs=[
        ("semantic.color.text.default","semantic.color.surface.default",4.5),
        ("semantic.color.text.secondary","semantic.color.surface.default",4.5),
        ("semantic.color.text.inverse","semantic.color.surface.inverse",4.5),
    ]
    for theme,resolved in themes.items():
        for fg,bg,min_ratio in required_pairs:
            ratio=contrast(resolved[fg],resolved[bg])
            if ratio is not None and ratio < min_ratio:
                raise ValueError(f"{theme}: contrast {fg} on {bg} = {ratio:.2f}, requires >= {min_ratio}")

    css=["/* Generated from DTCG source. Do not edit. */"]
    for theme in ("light","dark"):
        selector=':root, [data-theme="light"]' if theme=='light' else '[data-theme="dark"]'
        css.append(selector + " {")
        for key,value in sorted(themes[theme].items()):
            if key.startswith("semantic.") or key.startswith(("space.","radius.","size.","font.","motion.")):
                css.append(f"  {css_name(key)}: {value};")
        css.append("}")
    css.append(":root { color-scheme: light; }")
    css.append('[data-theme="dark"] { color-scheme: dark; }')
    out_json={"version":1,"themes":themes}
    panda = panda_theme({k: resolve_value(k, core) for k in core}, themes["light"], themes["dark"])
    if check:
        print(f"PASS: {len(core)} core tokens; {len(themes['light'])-len(core)} semantic light tokens; contrast checks passed")
        return
    DIST.mkdir(parents=True, exist_ok=True)
    (DIST/"tokens.css").write_text("\n".join(css)+"\n", encoding="utf-8")
    (DIST/"tokens.json").write_text(json.dumps(out_json,ensure_ascii=False,indent=2)+"\n", encoding="utf-8")
    (DIST/"panda-theme.json").write_text(json.dumps(panda,ensure_ascii=False,indent=2)+"\n", encoding="utf-8")
    ts = "/* Generated from DTCG source. Do not edit. */\nexport const engineeringPlatformTheme = " + json.dumps(panda, ensure_ascii=False, indent=2) + " as const;\n"
    (DIST/"panda-theme.ts").write_text(ts,encoding="utf-8")
    print(f"PASS: wrote {DIST/'tokens.css'}, tokens.json, panda-theme.json and panda-theme.ts")

if __name__ == "__main__":
    p=argparse.ArgumentParser(); p.add_argument("--check",action="store_true"); args=p.parse_args()
    try: build(args.check)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr); raise SystemExit(2)
