'use client';

import { useState, type ReactNode } from 'react';
import { Dialog, Modal, ModalOverlay } from 'react-aria-components';
import { IconButton } from '@engineering-platform/ui';

export interface NavigationItem {
  id: string;
  label: string;
  href: string;
  icon?: ReactNode;
  badge?: string | number;
  current?: boolean;
  disabled?: boolean;
  children?: NavigationItem[];
}

export interface NavigationGroup {
  id: string;
  label?: string;
  items: NavigationItem[];
}

export interface AppHeaderSlots {
  start?: ReactNode;
  search?: ReactNode;
  context?: ReactNode;
  actions?: ReactNode;
  user?: ReactNode;
}

export interface AppShellLabels {
  skipToContent: string;
  primaryNavigation: string;
  mobileNavigation: string;
  openNavigation: string;
  closeNavigation: string;
  collapseNavigation: string;
  expandNavigation: string;
}

export interface AppShellProps {
  brand: ReactNode;
  navigation: NavigationGroup[];
  header: AppHeaderSlots | ReactNode;
  labels: AppShellLabels;
  footer?: ReactNode;
  children: ReactNode;
  mobileNavigation?: ReactNode;
  sidebarFooter?: ReactNode;
  mainId?: string;
  defaultSidebarCollapsed?: boolean;
  onSidebarCollapsedChange?: (collapsed: boolean) => void;
}

function isHeaderSlots(value: AppHeaderSlots | ReactNode): value is AppHeaderSlots {
  return Boolean(value && typeof value === 'object' && !('type' in (value as object)) && ['start', 'search', 'context', 'actions', 'user'].some(key => key in (value as object)));
}

function NavigationItemView({ item }: { item: NavigationItem }) {
  return <li data-shell-navigation-item>
    <a
      href={item.disabled ? undefined : item.href}
      aria-label={item.label}
      aria-current={item.current ? 'page' : undefined}
      aria-disabled={item.disabled || undefined}
      data-current={item.current || undefined}
    >
      {item.icon ? <span data-shell-navigation-icon aria-hidden="true">{item.icon}</span> : null}
      <span data-shell-navigation-label>{item.label}</span>
      {item.badge !== undefined ? <span data-shell-navigation-badge>{item.badge}</span> : null}
    </a>
    {item.children?.length ? <ul data-shell-subnavigation>{item.children.map(child => <NavigationItemView key={child.id} item={child} />)}</ul> : null}
  </li>;
}

function NavigationList({ groups, label }: { groups: NavigationGroup[]; label: string }) {
  return <nav data-shell-navigation aria-label={label}>
    {groups.map(group => <section key={group.id} data-shell-navigation-group aria-label={group.label}>
      {group.label ? <h2>{group.label}</h2> : null}
      <ul>{group.items.map(item => <NavigationItemView key={item.id} item={item} />)}</ul>
    </section>)}
  </nav>;
}

function AppHeader({ value }: { value: AppHeaderSlots | ReactNode }) {
  if (!isHeaderSlots(value)) return <>{value}</>;
  return <div data-shell-header-layout>
    <div data-shell-header-start>{value.start}</div>
    <div data-shell-header-search>{value.search}</div>
    <div data-shell-header-context>{value.context}</div>
    <div data-shell-header-actions>{value.actions}</div>
    <div data-shell-header-user>{value.user}</div>
  </div>;
}

function DrawerContent({ brand, navigation, labels, sidebarFooter, close }: Pick<AppShellProps,'brand'|'navigation'|'labels'|'sidebarFooter'> & { close:()=>void }) {
  return <div data-shell-mobile-drawer>
    <div data-shell-brand-row>
      <div data-shell-brand>{brand}</div>
      <IconButton data-shell-mobile-close label={labels.closeNavigation} icon={<span aria-hidden="true">×</span>} variant="ghost" onPress={close}/>
    </div>
    <NavigationList groups={navigation} label={labels.mobileNavigation}/>
    {sidebarFooter ? <div data-shell-sidebar-footer>{sidebarFooter}</div> : null}
  </div>;
}

export function AppShell({ brand, navigation, header, labels, footer, children, mobileNavigation, sidebarFooter, mainId='main-content', defaultSidebarCollapsed=false, onSidebarCollapsedChange }: AppShellProps) {
  const [sidebarCollapsed,setSidebarCollapsed]=useState(defaultSidebarCollapsed);
  const [mobileOpen,setMobileOpen]=useState(false);
  const updateCollapsed=(value:boolean)=>{setSidebarCollapsed(value);onSidebarCollapsedChange?.(value)};

  return <div data-ep-shell="app" data-sidebar-collapsed={sidebarCollapsed || undefined}>
    <a data-shell-skip-link href={`#${mainId}`}>{labels.skipToContent}</a>
    <aside data-shell-sidebar aria-label={labels.primaryNavigation}>
      <div data-shell-brand-row>
        <div data-shell-brand>{brand}</div>
        <IconButton
          data-shell-collapse-trigger
          label={sidebarCollapsed ? labels.expandNavigation : labels.collapseNavigation}
          icon={<span aria-hidden="true">☰</span>}
          variant="ghost"
          onPress={()=>updateCollapsed(!sidebarCollapsed)}
        />
      </div>
      <NavigationList groups={navigation} label={labels.primaryNavigation}/>
      {sidebarFooter ? <div data-shell-sidebar-footer>{sidebarFooter}</div> : null}
    </aside>

    <ModalOverlay data-shell-mobile-overlay isOpen={mobileOpen} onOpenChange={setMobileOpen} isDismissable>
      <Modal data-shell-mobile-modal>
        <Dialog aria-label={labels.mobileNavigation}>
          {({close})=><DrawerContent brand={brand} navigation={navigation} labels={labels} sidebarFooter={sidebarFooter} close={close}/>}
        </Dialog>
      </Modal>
    </ModalOverlay>

    <header data-shell-header>
      <IconButton data-shell-mobile-trigger label={labels.openNavigation} icon={<span aria-hidden="true">☰</span>} variant="ghost" onPress={()=>setMobileOpen(true)}/>
      <AppHeader value={header}/>
    </header>
    <main data-shell-main id={mainId} tabIndex={-1}>{children}</main>
    {footer ? <footer data-shell-footer>{footer}</footer> : null}
    {mobileNavigation ? <nav data-shell-mobile-nav data-mobile-navigation aria-label={labels.mobileNavigation}>{mobileNavigation}</nav> : null}
  </div>;
}
