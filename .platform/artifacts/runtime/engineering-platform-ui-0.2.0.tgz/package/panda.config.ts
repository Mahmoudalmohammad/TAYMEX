import { defineConfig } from '@pandacss/dev';
import { engineeringPlatformTheme } from '../design-tokens/dist/panda-theme';

export default defineConfig({
  preflight: false,
  strictTokens: true,
  strictPropertyValues: true,
  jsxFramework: 'react',
  include: [
    './src/**/*.{ts,tsx}',
    '../ui-patterns/src/**/*.{ts,tsx}',
    '../app-shell/src/**/*.{ts,tsx}',
  ],
  outdir: './styled-system',
  theme: { extend: engineeringPlatformTheme },
});
