import { Button as AriaButton, type ButtonProps as AriaButtonProps } from 'react-aria-components';

export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';
export interface ButtonProps extends Omit<AriaButtonProps, 'className' | 'isPending'> {
  variant?: ButtonVariant;
  fullWidth?: boolean;
  isLoading?: boolean;
  loadingLabel?: string;
}

export function Button({ variant = 'primary', fullWidth = false, isLoading=false, loadingLabel, children, ...props }: ButtonProps) {
  if (isLoading && !loadingLabel) throw new Error('Button requires loadingLabel when isLoading is true.');
  return <AriaButton
    {...props}
    isPending={isLoading}
    aria-busy={isLoading || undefined}
    data-ep-ui="button"
    data-variant={variant}
    data-full-width={fullWidth || undefined}
    data-loading={isLoading || undefined}
  >{isLoading ? <><span data-button-spinner aria-hidden="true"/><span>{loadingLabel}</span></> : children}</AriaButton>;
}
