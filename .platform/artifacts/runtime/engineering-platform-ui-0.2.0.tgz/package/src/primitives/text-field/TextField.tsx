import { FieldError, Input, Label, Text, TextField as AriaTextField, type TextFieldProps as AriaTextFieldProps } from 'react-aria-components';

export type FieldStatus = 'default' | 'success' | 'loading';
export interface TextFieldProps extends Omit<AriaTextFieldProps, 'children' | 'className'> {
  label: string;
  description?: string;
  errorMessage?: string;
  placeholder?: string;
  status?: FieldStatus;
  statusMessage?: string;
  type?: 'text' | 'email' | 'url' | 'tel' | 'search';
  autoComplete?: string;
  inputMode?: 'none' | 'text' | 'tel' | 'url' | 'email' | 'numeric' | 'decimal' | 'search';
}
export function TextField({ label, description, errorMessage, placeholder, status='default', statusMessage, type='text', autoComplete, inputMode, ...props }: TextFieldProps) {
  return <AriaTextField {...props} data-ep-ui="text-field" data-status={status} aria-busy={status==='loading' || undefined}>
    <Label>{label}</Label>
    <Input placeholder={placeholder} type={type} autoComplete={autoComplete} inputMode={inputMode} />
    {description ? <Text slot="description">{description}</Text> : null}
    {statusMessage && status !== 'default' ? <span data-field-status aria-live="polite">{statusMessage}</span> : null}
    <FieldError>{errorMessage}</FieldError>
  </AriaTextField>;
}
