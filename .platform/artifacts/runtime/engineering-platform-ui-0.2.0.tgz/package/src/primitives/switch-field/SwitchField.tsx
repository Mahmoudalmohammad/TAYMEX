import { Switch } from 'react-aria-components';
export interface SwitchFieldProps { label:string; isSelected?:boolean; defaultSelected?:boolean; isDisabled?:boolean; onChange?:(selected:boolean)=>void; }
export function SwitchField({label,...props}:SwitchFieldProps){return <Switch {...props} data-ep-ui="switch-field"><span data-switch-track><span data-switch-thumb /></span><span>{label}</span></Switch>}
