import type { ReactNode } from 'react';
export type ToastTone='info'|'success'|'warning'|'danger';
export interface ToastProps { tone?:ToastTone; title:string; children?:ReactNode; action?:ReactNode; assertive?:boolean; }
export function Toast({tone='info',title,children,action,assertive=false}:ToastProps){const urgent=assertive||tone==='danger';return <section data-ep-ui="toast" data-tone={tone} role={urgent?'alert':'status'} aria-live={urgent?'assertive':'polite'}><div data-toast-content><strong>{title}</strong>{children?<div>{children}</div>:null}</div>{action?<div data-toast-action>{action}</div>:null}</section>}
