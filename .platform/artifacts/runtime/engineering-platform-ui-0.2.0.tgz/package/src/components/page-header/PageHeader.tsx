import type { ReactNode } from 'react';
export interface PageHeaderProps {
  title: ReactNode;
  description?: ReactNode;
  eyebrow?: ReactNode;
  breadcrumbs?: ReactNode;
  actions?: ReactNode;
  meta?: ReactNode;
}
export function PageHeader({title,description,eyebrow,breadcrumbs,actions,meta}:PageHeaderProps){
  return <header data-ep-ui="page-header" data-ep-page-header>
    <div data-page-header-main>{breadcrumbs}{eyebrow?<div data-page-header-eyebrow>{eyebrow}</div>:null}<h1>{title}</h1>{description?<div data-page-header-description>{description}</div>:null}{meta?<div data-page-header-meta>{meta}</div>:null}</div>
    {actions?<div data-page-header-actions>{actions}</div>:null}
  </header>;
}
