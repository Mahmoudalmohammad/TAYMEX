'use client';
import { useState } from 'react';
import { FieldError, Input, Label, Text, TextField } from 'react-aria-components';
import { Button } from '../../primitives/button';
export interface PasswordFieldProps { label:string; showLabel:string; hideLabel:string; description?:string; errorMessage?:string; placeholder?:string; isDisabled?:boolean; isInvalid?:boolean; autoComplete?:'current-password'|'new-password'|'one-time-code'|'off'; name?:string; }
export function PasswordField({label,showLabel,hideLabel,description,errorMessage,placeholder,autoComplete='current-password',...props}:PasswordFieldProps){const [visible,setVisible]=useState(false);return <TextField {...props} data-ep-ui="password-field"><Label>{label}</Label><div data-password-control><Input type={visible?'text':'password'} placeholder={placeholder} autoComplete={autoComplete}/><Button variant="ghost" aria-pressed={visible} onPress={()=>setVisible(value=>!value)}>{visible?hideLabel:showLabel}</Button></div>{description?<Text slot="description">{description}</Text>:null}<FieldError>{errorMessage}</FieldError></TextField>}
