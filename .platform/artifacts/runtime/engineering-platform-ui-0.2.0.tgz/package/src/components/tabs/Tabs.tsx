import type { ReactNode } from 'react';
import { Tab, TabList, TabPanel, Tabs as AriaTabs } from 'react-aria-components';
export interface TabsItem { id:string; label:ReactNode; content:ReactNode; isDisabled?:boolean; }
export interface TabsProps { label:string; items:TabsItem[]; selectedKey?:string; defaultSelectedKey?:string; onSelectionChange?:(key:string)=>void; }
export function Tabs({label,items,selectedKey,defaultSelectedKey,onSelectionChange}:TabsProps){return <AriaTabs data-ep-ui="tabs" selectedKey={selectedKey} defaultSelectedKey={defaultSelectedKey} onSelectionChange={key=>onSelectionChange?.(String(key))}><TabList aria-label={label}>{items.map(item=><Tab key={item.id} id={item.id} isDisabled={item.isDisabled}>{item.label}</Tab>)}</TabList>{items.map(item=><TabPanel key={item.id} id={item.id}>{item.content}</TabPanel>)}</AriaTabs>}
