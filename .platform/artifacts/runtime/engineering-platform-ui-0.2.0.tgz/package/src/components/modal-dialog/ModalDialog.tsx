import type { ReactNode } from 'react';
import { Dialog, DialogTrigger, Heading, Modal, ModalOverlay } from 'react-aria-components';
import { Button } from '../../primitives/button';

export interface ModalDialogProps {
  trigger: ReactNode;
  title: string;
  children: ReactNode;
  closeLabel: string;
  actions?: (close: () => void) => ReactNode;
  isDismissable?: boolean;
}

export function ModalDialog({trigger,title,children,closeLabel,actions,isDismissable=true}:ModalDialogProps){
  return <DialogTrigger>
    {trigger}
    <ModalOverlay data-ep-ui="modal-overlay" isDismissable={isDismissable}>
      <Modal data-ep-ui="modal">
        <Dialog aria-label={title}>{({close})=><>
          <Heading slot="title">{title}</Heading>
          <div data-modal-body>{children}</div>
          <div data-modal-actions>{actions?.(close)}<Button variant="secondary" onPress={close}>{closeLabel}</Button></div>
        </>}</Dialog>
      </Modal>
    </ModalOverlay>
  </DialogTrigger>;
}
