import { Button } from '../../primitives/button';
export interface PaginationProps{page:number;pageCount:number;onPageChange?:(page:number)=>void;label:string;previousLabel:string;nextLabel:string;pageLabel?:(page:number,pageCount:number)=>string;}
export function Pagination({page,pageCount,onPageChange,label,previousLabel,nextLabel,pageLabel}:PaginationProps){
  const safeCount=Math.max(1,pageCount); const safePage=Math.min(Math.max(1,page),safeCount);
  return <nav data-ep-ui="pagination" aria-label={label}>
    <Button variant="secondary" isDisabled={safePage<=1} onPress={()=>onPageChange?.(safePage-1)}>{previousLabel}</Button>
    <span aria-live="polite">{pageLabel?.(safePage,safeCount) ?? `${safePage} / ${safeCount}`}</span>
    <Button variant="secondary" isDisabled={safePage>=safeCount} onPress={()=>onPageChange?.(safePage+1)}>{nextLabel}</Button>
  </nav>;
}
