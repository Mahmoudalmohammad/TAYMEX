import type { ReactNode } from 'react';

export type AlertTone = 'info' | 'success' | 'warning' | 'danger';
export interface AlertProps {
  tone?: AlertTone;
  title?: ReactNode;
  children: ReactNode;
  actions?: ReactNode;
  assertive?: boolean;
}
export function Alert({ tone='info', title, children, actions, assertive=false }: AlertProps) {
  return <section data-ep-ui="alert" data-tone={tone} role={assertive || tone==='danger' ? 'alert' : 'status'} aria-live={assertive || tone==='danger' ? 'assertive' : 'polite'}>
    <div data-alert-content>{title ? <strong data-alert-title>{title}</strong> : null}<div>{children}</div></div>
    {actions ? <div data-alert-actions>{actions}</div> : null}
  </section>;
}
