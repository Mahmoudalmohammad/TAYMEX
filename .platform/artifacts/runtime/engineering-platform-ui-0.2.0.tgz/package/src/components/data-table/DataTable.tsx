import type { ReactNode } from 'react';
import { Cell, Column, Row, Table, TableBody, TableHeader } from 'react-aria-components';
export type DataTableDensity='compact'|'default'|'comfortable';
export type DataTableAlignment='start'|'center'|'end'|'numeric';
export interface DataTableColumn<T>{id:string;header:string;cell:(row:T)=>ReactNode;isRowHeader?:boolean;align?:DataTableAlignment;}
export interface DataTableProps<T>{columns:DataTableColumn<T>[];rows:T[];getRowId:(row:T)=>string;label:string;empty?:ReactNode;density?:DataTableDensity;}
export function DataTable<T>({columns,rows,getRowId,label,empty,density='default'}:DataTableProps<T>){
  const columnMap=new Map(columns.map(column=>[column.id,column] as const));
  if(!rows.length&&empty)return <div data-ep-ui="data-table-empty">{empty}</div>;
  return <div data-ep-ui="data-table-region" role="region" aria-label={label} tabIndex={0}>
    <Table data-ep-ui="data-table" data-density={density} aria-label={label}>
      <TableHeader>{columns.map(c=><Column key={c.id} id={c.id} isRowHeader={c.isRowHeader} data-align={c.align ?? 'start'}>{c.header}</Column>)}</TableHeader>
      <TableBody items={rows}>{row=><Row id={getRowId(row)} columns={columns}>{column=>{const c=columnMap.get(String(column));return <Cell data-align={c?.align ?? 'start'}>{c?.cell(row)}</Cell>}}</Row>}</TableBody>
    </Table>
  </div>;
}
