import type { ReactNode } from 'react';
export type BadgeTone='neutral'|'success'|'warning'|'danger'|'info';
export function Badge({tone='neutral',children}:{tone?:BadgeTone;children:ReactNode}){return <span data-ep-ui="badge" data-tone={tone}>{children}</span>}
