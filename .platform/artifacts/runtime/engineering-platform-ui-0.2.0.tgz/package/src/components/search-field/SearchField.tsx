import { Button, Input, Label, SearchField as AriaSearchField, type SearchFieldProps as AriaSearchFieldProps } from 'react-aria-components';
export interface SearchFieldProps extends Omit<AriaSearchFieldProps,'children'|'className'> { label:string; placeholder?:string; clearLabel:string; }
export function SearchField({label,placeholder,clearLabel,...props}:SearchFieldProps){return <AriaSearchField {...props} data-ep-ui="search-field"><Label>{label}</Label><div data-search-control><Input placeholder={placeholder}/><Button slot="clear" aria-label={clearLabel}>×</Button></div></AriaSearchField>}
