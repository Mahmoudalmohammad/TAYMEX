import type { ReactNode } from 'react'; import { Button, type ButtonProps } from '../../primitives/button';
export interface IconButtonProps extends Omit<ButtonProps, 'children'> { label: string; icon: ReactNode; }
export function IconButton({ label, icon, ...props }: IconButtonProps) { return <Button {...props} aria-label={label}>{icon}</Button>; }
