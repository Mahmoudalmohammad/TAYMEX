import { FieldError, Label, Text, TextArea, TextField } from 'react-aria-components';
export interface TextareaFieldProps { label:string; description?:string; errorMessage?:string; placeholder?:string; isDisabled?:boolean; }
export function TextareaField({label,description,errorMessage,placeholder,...props}:TextareaFieldProps){return <TextField {...props} data-ep-ui="textarea-field"><Label>{label}</Label><TextArea placeholder={placeholder}/>{description?<Text slot="description">{description}</Text>:null}<FieldError>{errorMessage}</FieldError></TextField>}
