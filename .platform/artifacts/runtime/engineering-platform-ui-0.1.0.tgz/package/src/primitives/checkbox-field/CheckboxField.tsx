import { Checkbox } from 'react-aria-components';
export interface CheckboxFieldProps { label:string; isSelected?:boolean; defaultSelected?:boolean; isDisabled?:boolean; onChange?:(selected:boolean)=>void; }
export function CheckboxField({label,...props}:CheckboxFieldProps){return <Checkbox {...props} data-ep-ui="checkbox-field"><span data-checkbox-indicator aria-hidden="true">✓</span><span>{label}</span></Checkbox>}
