import { FieldError, Input, Label, Text, TextField as AriaTextField, type TextFieldProps as AriaTextFieldProps } from 'react-aria-components';

export interface TextFieldProps extends Omit<AriaTextFieldProps, 'children' | 'className'> {
  label: string;
  description?: string;
  errorMessage?: string;
  placeholder?: string;
}
export function TextField({ label, description, errorMessage, placeholder, ...props }: TextFieldProps) {
  return <AriaTextField {...props} data-ep-ui="text-field">
    <Label>{label}</Label>
    <Input placeholder={placeholder} />
    {description ? <Text slot="description">{description}</Text> : null}
    <FieldError>{errorMessage}</FieldError>
  </AriaTextField>;
}
