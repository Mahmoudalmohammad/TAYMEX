import { Button as AriaButton, type ButtonProps as AriaButtonProps } from 'react-aria-components';

export type ButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';
export interface ButtonProps extends Omit<AriaButtonProps, 'className'> {
  variant?: ButtonVariant;
  fullWidth?: boolean;
}

export function Button({ variant = 'primary', fullWidth = false, ...props }: ButtonProps) {
  return <AriaButton {...props} data-ep-ui="button" data-variant={variant} data-full-width={fullWidth || undefined} />;
}
