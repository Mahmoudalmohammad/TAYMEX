export interface SkeletonProps { lines?: number; label?: string; }
export function Skeleton({lines=3,label='Loading content'}:SkeletonProps){return <div data-ep-ui="skeleton" role="status" aria-label={label}>{Array.from({length:Math.max(1,lines)},(_,i)=><span key={i} data-skeleton-line aria-hidden="true" />)}</div>}
