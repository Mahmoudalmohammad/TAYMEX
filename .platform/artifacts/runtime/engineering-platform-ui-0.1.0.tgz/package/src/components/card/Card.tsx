import type { HTMLAttributes, ReactNode } from 'react';
export interface CardProps extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'style'> { title?: ReactNode; children: ReactNode; }
export function Card({ title, children, ...props }: CardProps) {
  return <section {...props} data-ep-ui="card">{title ? <header data-card-title>{title}</header> : null}<div data-card-body>{children}</div></section>;
}
