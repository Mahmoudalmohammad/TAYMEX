import { Button } from '../../primitives/button';
export interface PaginationProps{page:number;pageCount:number;onPageChange?:(page:number)=>void;label?:string;}
export function Pagination({page,pageCount,onPageChange,label='Pagination'}:PaginationProps){return <nav data-ep-ui="pagination" aria-label={label}><Button variant="secondary" isDisabled={page<=1} onPress={()=>onPageChange?.(page-1)}>Previous</Button><span aria-live="polite">{page} / {pageCount}</span><Button variant="secondary" isDisabled={page>=pageCount} onPress={()=>onPageChange?.(page+1)}>Next</Button></nav>}
