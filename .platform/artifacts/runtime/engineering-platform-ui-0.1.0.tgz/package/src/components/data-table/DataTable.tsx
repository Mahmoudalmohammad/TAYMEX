import type { ReactNode } from 'react';
import { Cell, Column, Row, Table, TableBody, TableHeader } from 'react-aria-components';
export interface DataTableColumn<T>{id:string;header:string;cell:(row:T)=>ReactNode;isRowHeader?:boolean;}
export interface DataTableProps<T>{columns:DataTableColumn<T>[];rows:T[];getRowId:(row:T)=>string;label:string;empty?:ReactNode;}
export function DataTable<T>({columns,rows,getRowId,label,empty}:DataTableProps<T>){
  if(!rows.length&&empty)return <div data-ep-ui="data-table-empty">{empty}</div>;
  return <div data-ep-ui="data-table-region" role="region" aria-label={label} tabIndex={0}>
    <Table data-ep-ui="data-table" aria-label={label}>
      <TableHeader>{columns.map(c=><Column key={c.id} id={c.id} isRowHeader={c.isRowHeader}>{c.header}</Column>)}</TableHeader>
      <TableBody items={rows}>{row=><Row id={getRowId(row)} columns={columns}>{column=><Cell>{column.cell(row)}</Cell>}</Row>}</TableBody>
    </Table>
  </div>;
}
