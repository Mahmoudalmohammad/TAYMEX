from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import tarfile
from typing import Iterable

import yaml


@dataclass
class BoundaryFinding:
    rule: str
    message: str
    path: str | None = None

    def as_dict(self) -> dict:
        return {"rule": self.rule, "message": self.message, "path": self.path, "severity": "blocking"}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_yaml(path: Path) -> dict:
    if not path.exists():
        raise RuntimeError(f"ART-001: required artifact lock is missing: {path}")
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        raise RuntimeError(f"ART-001: artifact lock cannot be parsed: {exc}") from exc


def _package_jsons(repo: Path) -> Iterable[Path]:
    for path in sorted(repo.rglob("package.json")):
        if any(part in {"node_modules", ".git", ".next", "dist", "build"} for part in path.relative_to(repo).parts):
            continue
        yield path


def _tgz_manifest(path: Path) -> dict:
    try:
        with tarfile.open(path, "r:gz") as tf:
            member = tf.getmember("package/package.json")
            raw = tf.extractfile(member)
            if raw is None:
                raise RuntimeError("missing package/package.json")
            return json.loads(raw.read().decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"ART-001: invalid npm artifact {path}: {exc}") from exc


def verify_consumer_boundary(repo: Path, lock_path: Path | None = None) -> tuple[list[BoundaryFinding], dict]:
    repo = repo.resolve()
    lock = (lock_path or (repo / ".platform" / "runtime.lock.yaml")).resolve()
    data = _load_yaml(lock)
    artifacts = data.get("artifacts", []) or []
    findings: list[BoundaryFinding] = []
    locked_by_name: dict[str, dict] = {}

    if data.get("consumerMode") != "independent-repository":
        findings.append(BoundaryFinding("ART-001", "consumerMode must be independent-repository", str(lock.relative_to(repo)) if lock.is_relative_to(repo) else str(lock)))

    for item in artifacts:
        name = item.get("name")
        version = item.get("version")
        rel_file = item.get("file")
        expected = item.get("sha256")
        if not name or not version or not rel_file or not expected:
            findings.append(BoundaryFinding("ART-001", "artifact entry requires name/version/file/sha256", str(lock)))
            continue
        locked_by_name[name] = item
        artifact = (repo / rel_file).resolve()
        if not artifact.is_relative_to(repo):
            findings.append(BoundaryFinding("ART-001", "artifact path escapes consumer repository", rel_file))
            continue
        if not artifact.exists():
            findings.append(BoundaryFinding("ART-001", "locked runtime artifact is missing", rel_file))
            continue
        actual = _sha256(artifact)
        if actual != expected:
            findings.append(BoundaryFinding("ART-002", f"artifact SHA-256 mismatch: expected {expected}, got {actual}", rel_file))
            continue
        try:
            manifest = _tgz_manifest(artifact)
        except RuntimeError as exc:
            findings.append(BoundaryFinding("ART-001", str(exc), rel_file))
            continue
        if manifest.get("name") != name or manifest.get("version") != version:
            findings.append(BoundaryFinding("ART-001", f"artifact identity mismatch: lock={name}@{version}, package={manifest.get('name')}@{manifest.get('version')}", rel_file))
        for group in ("dependencies", "devDependencies", "peerDependencies", "optionalDependencies"):
            for dep, spec in (manifest.get(group) or {}).items():
                if isinstance(spec, str) and (spec.startswith("workspace:") or spec.startswith("link:")):
                    findings.append(BoundaryFinding("ART-003", f"published artifact contains forbidden {spec.split(':',1)[0]} dependency {dep}: {spec}", rel_file))

    used_platform_deps: dict[str, list[str]] = {}
    for pkg in _package_jsons(repo):
        rel = pkg.relative_to(repo).as_posix()
        try:
            manifest = json.loads(pkg.read_text(encoding="utf-8"))
        except Exception as exc:
            findings.append(BoundaryFinding("ART-001", f"invalid package.json: {exc}", rel))
            continue
        for group in ("dependencies", "devDependencies", "peerDependencies", "optionalDependencies"):
            for dep, spec in (manifest.get(group) or {}).items():
                if not isinstance(spec, str):
                    continue
                if spec.startswith("workspace:") or spec.startswith("link:"):
                    findings.append(BoundaryFinding("ART-003", f"consumer package uses forbidden local-source dependency {dep}: {spec}", rel))
                if "ENGINEERING_PLATFORM" in spec or "engineering_platform" in spec.lower() and (spec.startswith("file:") or spec.startswith("../") or spec.startswith("/")):
                    findings.append(BoundaryFinding("ART-003", f"consumer dependency points at platform source: {dep}: {spec}", rel))
                if dep.startswith("@engineering-platform/"):
                    used_platform_deps.setdefault(dep, []).append(rel)
                    locked = locked_by_name.get(dep)
                    if locked is None:
                        findings.append(BoundaryFinding("ART-001", f"platform dependency {dep} is not present in runtime.lock.yaml", rel))
                        continue
                    expected_spec = f"file:{locked['file']}"
                    # file: is resolved relative to the package manifest, so compare normalized paths.
                    if spec.startswith("file:"):
                        resolved = (pkg.parent / spec[5:]).resolve()
                        expected_resolved = (repo / locked["file"]).resolve()
                        if resolved != expected_resolved:
                            findings.append(BoundaryFinding("ART-003", f"platform dependency {dep} does not resolve to locked artifact {locked['file']}", rel))
                    else:
                        findings.append(BoundaryFinding("ART-003", f"bootstrap consumer must use locked file: artifact for {dep}; got {spec}", rel))

    # Symlinks can silently recreate source-link coupling even when package.json looks clean.
    for path in sorted(repo.rglob("*")):
        if not path.is_symlink():
            continue
        target = path.resolve()
        if not target.is_relative_to(repo):
            findings.append(BoundaryFinding("ART-003", f"symlink escapes consumer repository to {target}", path.relative_to(repo).as_posix()))

    metadata = {
        "lock": str(lock),
        "lockedArtifacts": sorted(locked_by_name),
        "usedPlatformDependencies": used_platform_deps,
    }
    return findings, metadata
