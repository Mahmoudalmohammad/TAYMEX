#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const ts = require('typescript');

const repo = path.resolve(process.argv[2] || process.cwd());
const cfgPath = process.argv[3] ? path.resolve(process.argv[3]) : null;
let cfg = { scanRoots: ['packages','capabilities','apps'], ignore: ['node_modules','.git','.nx','.agent-context','.governance','dist','build','.next'] };
if (cfgPath && fs.existsSync(cfgPath)) {
  cfg = JSON.parse(fs.readFileSync(cfgPath,'utf8'));
}
const ignored = new Set(cfg.ignore || []);
function walk(dir, out=[]) {
  if (!fs.existsSync(dir)) return out;
  for (const ent of fs.readdirSync(dir,{withFileTypes:true})) {
    if (ignored.has(ent.name)) continue;
    const p=path.join(dir,ent.name);
    if (ent.isDirectory()) walk(p,out);
    else if ((p.endsWith('.ts') || p.endsWith('.tsx')) && !p.endsWith('.d.ts')) out.push(p);
  }
  return out;
}
function hasMod(node, kind) { return !!node.modifiers?.some(m=>m.kind===kind); }
function isExported(node) { return hasMod(node, ts.SyntaxKind.ExportKeyword) || hasMod(node, ts.SyntaxKind.DefaultKeyword); }
function text(node, sf) { return node ? node.getText(sf) : null; }
function rel(p){ return path.relative(repo,p).replaceAll('\\','/'); }
function paramSig(p,sf){
  return { name: text(p.name,sf), type: p.type ? text(p.type,sf) : 'inferred', optional: !!p.questionToken || !!p.initializer };
}
function declSignature(node,sf){
  if (ts.isFunctionDeclaration(node)) return { parameters:(node.parameters||[]).map(p=>paramSig(p,sf)), returnType: node.type?text(node.type,sf):'inferred', async: hasMod(node,ts.SyntaxKind.AsyncKeyword) };
  return null;
}
function access(node){
  if (hasMod(node,ts.SyntaxKind.PrivateKeyword)) return 'private';
  if (hasMod(node,ts.SyntaxKind.ProtectedKeyword)) return 'protected';
  return 'public';
}
function callName(expr,sf){
  if (ts.isIdentifier(expr)) return expr.text;
  if (ts.isPropertyAccessExpression(expr)) return expr.name.text;
  return text(expr,sf);
}
function firstString(call){
  const a=call.arguments?.[0];
  return a && ts.isStringLiteralLike(a) ? a.text : null;
}
function columnInfo(prop,sf){
  let key=null, init=null;
  if (ts.isPropertyAssignment(prop)) { key=text(prop.name,sf); init=prop.initializer; }
  else if (ts.isShorthandPropertyAssignment(prop)) { key=prop.name.text; init=prop.name; }
  else return null;
  let dbName=null, builder=null;
  let cur=init;
  while (cur && ts.isCallExpression(cur)) {
    if (!builder) builder=callName(cur.expression,sf);
    const s=firstString(cur); if (s && !dbName) dbName=s;
    if (ts.isPropertyAccessExpression(cur.expression)) cur=cur.expression.expression; else break;
  }
  return { property:key?.replace(/^['\"]|['\"]$/g,''), column:dbName, builder, expression:text(init,sf) };
}

const files=[];
for(const r of cfg.scanRoots||[]) walk(path.join(repo,r),files);
const symbols=[], tables=[], imports=[];
const schemaAliases=new Map(); // file::identifier -> schema name

for(const file of files){
  const src=fs.readFileSync(file,'utf8');
  const sf=ts.createSourceFile(file,src,ts.ScriptTarget.Latest,true,file.endsWith('.tsx')?ts.ScriptKind.TSX:ts.ScriptKind.TS);
  // First pass: pgSchema aliases
  for(const st of sf.statements){
    if(ts.isVariableStatement(st)){
      for(const d of st.declarationList.declarations){
        if(ts.isIdentifier(d.name) && d.initializer && ts.isCallExpression(d.initializer) && callName(d.initializer.expression,sf)==='pgSchema'){
          const s=firstString(d.initializer); if(s) schemaAliases.set(file+'::'+d.name.text,s);
        }
      }
    }
  }
  for(const st of sf.statements){
    if(ts.isImportDeclaration(st) && ts.isStringLiteralLike(st.moduleSpecifier)) imports.push({file:rel(file),specifier:st.moduleSpecifier.text});
    if(isExported(st)){
      let kind=null,name=null,sig=null, members=[];
      if(ts.isFunctionDeclaration(st) && st.name){kind='function';name=st.name.text;sig=declSignature(st,sf);}
      else if(ts.isClassDeclaration(st) && st.name){
        kind='class';name=st.name.text;
        members=st.members.filter(m=>ts.isMethodDeclaration(m) && m.name && access(m)==='public').map(m=>({
          kind:'method',name:text(m.name,sf),parameters:(m.parameters||[]).map(p=>paramSig(p,sf)),returnType:m.type?text(m.type,sf):'inferred',async:hasMod(m,ts.SyntaxKind.AsyncKeyword)
        }));
      }
      else if(ts.isInterfaceDeclaration(st)){kind='interface';name=st.name.text;members=st.members.map(m=>({kind:ts.SyntaxKind[m.kind],name:m.name?text(m.name,sf):null,type:m.type?text(m.type,sf):null}));}
      else if(ts.isTypeAliasDeclaration(st)){kind='type';name=st.name.text;sig={type:text(st.type,sf)};}
      else if(ts.isEnumDeclaration(st)){kind='enum';name=st.name.text;members=st.members.map(m=>({name:text(m.name,sf),value:m.initializer?text(m.initializer,sf):null}));}
      else if(ts.isVariableStatement(st)){
        for(const d of st.declarationList.declarations){ if(ts.isIdentifier(d.name)) symbols.push({file:rel(file),kind:'variable',name:d.name.text,type:d.type?text(d.type,sf):'inferred'}); }
      }
      if(name) symbols.push({file:rel(file),kind,name,...(sig||{}),...(members.length?{members}: {})});
    }
    // Drizzle table declarations can be exported or internal; table truth is still important.
    if(ts.isVariableStatement(st)){
      for(const d of st.declarationList.declarations){
        if(!ts.isIdentifier(d.name) || !d.initializer || !ts.isCallExpression(d.initializer)) continue;
        const call=d.initializer; const cname=callName(call.expression,sf);
        let tableName=null, schemaName=null;
        if(['pgTable','mysqlTable','sqliteTable'].includes(cname)) tableName=firstString(call);
        else if(cname==='table' && ts.isPropertyAccessExpression(call.expression)){
          const obj=call.expression.expression;
          if(ts.isIdentifier(obj)) schemaName=schemaAliases.get(file+'::'+obj.text)||null;
          tableName=firstString(call);
        }
        if(!tableName) continue;
        const obj=call.arguments?.[1]; const columns=[];
        if(obj && ts.isObjectLiteralExpression(obj)) for(const p of obj.properties){ const c=columnInfo(p,sf); if(c) columns.push(c); }
        tables.push({file:rel(file),symbol:d.name.text,table:tableName,schema:schemaName,physicalName:schemaName?`${schemaName}.${tableName}`:tableName,columns});
      }
    }
  }
}
console.log(JSON.stringify({symbols,tables,imports},null,2));
