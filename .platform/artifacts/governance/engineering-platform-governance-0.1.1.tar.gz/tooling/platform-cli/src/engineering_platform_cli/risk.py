from __future__ import annotations
from .patterns import matches


def risk_index(cfg: dict, risk: str) -> int:
    return cfg["riskOrder"].index(risk)


def max_risk(cfg: dict, *risks: str) -> str:
    return max(risks, key=lambda r: risk_index(cfg, r))


def infer_minimum_risk(task: dict, changed_paths: list[str], cfg: dict) -> tuple[str, list[dict]]:
    minimum = cfg["modeMinimumRisk"].get(task["mode"], "R1")
    reasons = [{"risk": minimum, "reason": f"mode:{task['mode']}"}]
    for path in changed_paths:
        for entry in cfg.get("protectedPaths", []):
            if matches(path, entry["pattern"]):
                minimum = max_risk(cfg, minimum, entry["minimumRisk"])
                reasons.append({"risk": entry["minimumRisk"], "reason": entry.get("rule", "protected-path"), "path": path})
    return minimum, reasons
