from __future__ import annotations
from pathlib import Path
import json
import math
import re
from .contracts import validate_document
from .io_utils import load_data, dump_text

HEX_RE = re.compile(r'^#[0-9A-Fa-f]{6}$')
PX_RE = re.compile(r'^(-?\d+(?:\.\d+)?)px$')

class ThemeFailure(Exception):
    pass


def _css_var(key: str) -> str:
    return '--ep-' + key.replace('.', '-').lower()


def _hex_rgb(value: str):
    value=value.lstrip('#')
    return tuple(int(value[i:i+2],16)/255 for i in (0,2,4))


def _linear(v: float) -> float:
    return v/12.92 if v <= .04045 else ((v+.055)/1.055)**2.4


def contrast_ratio(a: str,b: str) -> float:
    def lum(x):
        r,g,b=(_linear(v) for v in _hex_rgb(x))
        return .2126*r+.7152*g+.0722*b
    l1,l2=lum(a),lum(b)
    hi,lo=max(l1,l2),min(l1,l2)
    return (hi+.05)/(lo+.05)


def _flatten_allowed(policy: dict) -> tuple[set[str],dict[str,str]]:
    allowed=set(); kinds={}
    for kind,keys in (policy.get('allowedOverrides') or {}).items():
        for key in keys or []:
            allowed.add(key); kinds[key]=kind
    return allowed,kinds


def _base_tokens(root: Path) -> dict:
    path=root/'packages/design-tokens/dist/tokens.json'
    if not path.exists():
        raise ThemeFailure('Compiled design tokens are missing; run tokens:build first.')
    return json.loads(path.read_text(encoding='utf-8'))['themes']


def load_theme_profile(path: Path, root: Path, cfg: dict) -> dict:
    data=validate_document(path, root/cfg['schemas']['themeProfile'])
    policy=load_data(root/cfg.get('themePolicy','tooling/policies/theme-policy.yaml'))
    allowed,kinds=_flatten_allowed(policy)
    base=_base_tokens(root)
    errors=[]
    for mode,items in (data.get('overrides') or {}).items():
        for key,value in (items or {}).items():
            if key not in allowed:
                errors.append(f'{mode}.{key}: token is not project-overridable')
                continue
            if key not in base['light']:
                errors.append(f'{mode}.{key}: token does not exist in platform design tokens')
                continue
            kind=kinds[key]
            if kind=='color':
                if not isinstance(value,str) or not HEX_RE.fullmatch(value):
                    errors.append(f'{mode}.{key}: color must be 6-digit hex')
            elif kind=='dimension':
                text=str(value)
                m=PX_RE.fullmatch(text)
                if not m:
                    errors.append(f'{mode}.{key}: dimension must use px')
                else:
                    val=float(m.group(1)); lim=(policy.get('constraints',{}).get('dimensions',{}).get(key) or {})
                    if 'minPx' in lim and val<float(lim['minPx']): errors.append(f'{mode}.{key}: {val}px < minimum {lim["minPx"]}px')
                    if 'maxPx' in lim and val>float(lim['maxPx']): errors.append(f'{mode}.{key}: {val}px > maximum {lim["maxPx"]}px')
            elif kind=='fontFamily':
                text=str(value)
                if any(x in text.lower() for x in ('url(', '{', '}', ';', '<', '>')):
                    errors.append(f'{mode}.{key}: unsafe font-family value')
    if errors: raise ThemeFailure('Theme profile validation failed:\n- '+'\n- '.join(errors))

    # Validate effective contrast after overrides. Common applies to both modes; mode override wins.
    for mode in ('light','dark'):
        effective=dict(base[mode])
        effective.update((data.get('overrides') or {}).get('common') or {})
        effective.update((data.get('overrides') or {}).get(mode) or {})
        for pair in policy.get('contrastPairs',[]) or []:
            fg,bg=effective.get(pair['foreground']),effective.get(pair['background'])
            if isinstance(fg,str) and HEX_RE.fullmatch(fg) and isinstance(bg,str) and HEX_RE.fullmatch(bg):
                ratio=contrast_ratio(fg,bg)
                if ratio+1e-9<float(pair['minimum']):
                    raise ThemeFailure(f"Theme contrast failed in {mode}: {pair['foreground']} on {pair['background']} = {ratio:.2f}, minimum {pair['minimum']}")
    return data


def build_theme_profile(path: Path, root: Path, cfg: dict, out: Path | None=None) -> Path:
    data=load_theme_profile(path,root,cfg)
    out=out or path.with_suffix('.css')
    common=(data.get('overrides') or {}).get('common') or {}
    lines=[f'/* Generated governed theme: {data["id"]}. Do not edit by hand. */']
    if common:
        lines.append(f'[data-project-theme="{data["id"]}"] {{')
        lines.extend(f'  {_css_var(k)}: {v};' for k,v in sorted(common.items()))
        lines.append('}')
    for mode in ('light','dark'):
        items=(data.get('overrides') or {}).get(mode) or {}
        if not items: continue
        lines.append(f'[data-project-theme="{data["id"]}"][data-theme="{mode}"], [data-project-theme="{data["id"]}"] [data-theme="{mode}"] {{')
        lines.extend(f'  {_css_var(k)}: {v};' for k,v in sorted(items.items()))
        lines.append('}')
    dump_text(out,'\n'.join(lines)+'\n')
    return out


def explain_theme(path: Path, root: Path, cfg: dict, key: str, mode: str) -> dict:
    data=load_theme_profile(path,root,cfg); base=_base_tokens(root)
    if mode not in base: raise ThemeFailure(f'Unknown mode: {mode}')
    if key not in base[mode]: raise ThemeFailure(f'Unknown design token: {key}')
    source='platform'; value=base[mode][key]
    common=(data.get('overrides') or {}).get('common') or {}
    specific=(data.get('overrides') or {}).get(mode) or {}
    if key in common: source='project.common'; value=common[key]
    if key in specific: source=f'project.{mode}'; value=specific[key]
    return {'theme':data['id'],'mode':mode,'key':key,'effectiveValue':value,'source':source,'platformValue':base[mode][key]}
