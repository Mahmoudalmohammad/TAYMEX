from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, yaml, os
from jsonschema import Draft202012Validator
from .contracts import validate_document
from .io_utils import load_data, dump_json
from .registries import RegistryFailure

HTTP_METHODS={"get","put","post","delete","options","head","patch","trace","query"}


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def find_api_contract_manifests(repo: Path) -> list[Path]:
    names={"api.contract.yaml","api.contract.yml","api.contract.json"}
    ignored={"node_modules",".git",".nx",".agent-context",".governance","dist","build",".next"}
    return sorted(p for p in repo.rglob("*") if p.name in names and not any(x in ignored for x in p.parts))


def _walk_refs(value, refs: list[str]):
    if isinstance(value, dict):
        for k,v in value.items():
            if k == "$ref" and isinstance(v,str): refs.append(v)
            else: _walk_refs(v,refs)
    elif isinstance(value,list):
        for x in value: _walk_refs(x,refs)


def validate_openapi_document(doc: dict, expected_version: str, path: Path) -> list[dict]:
    if not isinstance(doc,dict): raise RegistryFailure(f"OpenAPI document must be an object: {path}")
    if doc.get("openapi") != expected_version:
        raise RegistryFailure(f"OpenAPI version mismatch in {path}: expected {expected_version}, got {doc.get('openapi')}")
    if not isinstance(doc.get("info"),dict) or not doc["info"].get("title"):
        raise RegistryFailure(f"OpenAPI info.title missing: {path}")
    if not isinstance(doc.get("paths"),dict): raise RegistryFailure(f"OpenAPI paths missing: {path}")
    operations=[]; ids={}
    for route,item in doc.get("paths",{}).items():
        if not isinstance(item,dict): continue
        for method,op in item.items():
            if method.lower() not in HTTP_METHODS or not isinstance(op,dict): continue
            oid=op.get("operationId")
            if not oid: raise RegistryFailure(f"Operation missing operationId: {method.upper()} {route} ({path})")
            if oid in ids: raise RegistryFailure(f"Duplicate operationId {oid}: {route} and {ids[oid]} ({path})")
            ids[oid]=route
            operations.append({"operationId":oid,"method":method.upper(),"path":route,"security":op.get("security",doc.get("security")),"responses":sorted((op.get("responses") or {}).keys())})
    refs=[]; _walk_refs(doc,refs)
    schemas=(doc.get("components") or {}).get("schemas") or {}
    for ref in refs:
        prefix="#/components/schemas/"
        if ref.startswith(prefix) and ref[len(prefix):] not in schemas:
            raise RegistryFailure(f"Unresolved local schema ref {ref} ({path})")
    return operations


def load_api_contracts(repo: Path, root: Path, cfg: dict) -> dict[str, tuple[dict,Path,dict,list[dict]]]:
    out={}
    schema=root/cfg["schemas"]["apiContract"]
    for mp in find_api_contract_manifests(repo):
        manifest=validate_document(mp,schema)
        cid=manifest["id"]
        if cid in out: raise RegistryFailure(f"Duplicate API contract id {cid}: {mp} and {out[cid][1]}")
        source=repo/manifest["source"]; oas_path=repo/manifest["openapi"]
        if not source.exists(): raise RegistryFailure(f"API contract source missing for {cid}: {source}")
        if not oas_path.exists(): raise RegistryFailure(f"Generated OpenAPI missing for {cid}: {oas_path}")
        doc=load_data(oas_path)
        expected=manifest["operationalOpenApi"]
        operations=validate_openapi_document(doc,expected,oas_path)
        source_hash=_sha256(source)
        if doc.get("x-engineering-platform-source-sha256") != source_hash:
            raise RegistryFailure(f"API-003: generated OpenAPI is stale or not stamped from current source for {cid}")
        out[cid]=(manifest,mp,doc,operations)
    return out


def build_typescript_index(repo: Path, root: Path, cfg: dict) -> dict:
    truth_cfg=cfg.get("repositoryTruth",{})
    script=root/"tooling/repository-truth/index_ts.cjs"
    if not script.exists():
        script=Path(__file__).resolve().parent/"resources"/"index_ts.cjs"
    if not script.exists():
        raise RegistryFailure("MODEL-001: TypeScript repository-truth indexer is missing from both project root and pinned governance artifact")
    payload=json.dumps({"scanRoots":truth_cfg.get("scanRoots",[]),"ignore":truth_cfg.get("ignore",[])})
    env=os.environ.copy()
    node_path=str(repo/"node_modules")
    env["NODE_PATH"]=node_path + (os.pathsep + env["NODE_PATH"] if env.get("NODE_PATH") else "")
    cp=subprocess.run(["node",str(script),str(repo),"-"],input=None,text=True,capture_output=True,env=env,cwd=repo)
    # script currently expects a JSON config path, so run using a small temp file for portability.
    if cp.returncode != 0 or not cp.stdout.strip():
        import tempfile
        with tempfile.NamedTemporaryFile("w",suffix=".json",delete=False,encoding="utf-8") as f:
            f.write(payload); tmp=f.name
        cp=subprocess.run(["node",str(script),str(repo),tmp],text=True,capture_output=True,env=env,cwd=repo)
        Path(tmp).unlink(missing_ok=True)
    if cp.returncode != 0:
        raise RegistryFailure("MODEL-001: TypeScript repository-truth indexer failed: "+(cp.stderr.strip() or cp.stdout.strip()))
    try: return json.loads(cp.stdout)
    except Exception as e: raise RegistryFailure(f"MODEL-001: invalid TypeScript index output: {e}")


def _module_for_file(rel: str, modules: dict[str,tuple[dict,Path]]) -> str|None:
    matches=[]
    for mid,(m,_p) in modules.items():
        for sr in m.get("sourceRoots",[]) or []:
            sr=sr.rstrip("/")
            if rel==sr or rel.startswith(sr+"/"): matches.append((len(sr),mid))
    return max(matches)[1] if matches else None


def validate_data_ownership(ts_index: dict, modules: dict[str,tuple[dict,Path]]) -> list[dict]:
    declared={}; findings=[]
    for mid,(m,mp) in modules.items():
        for item in m.get("data",{}).get("owns",[]) or []:
            if item in declared: raise RegistryFailure(f"DATA-001: data ownership {item} declared by both {mid} and {declared[item]}")
            declared[item]=mid
    actual=[]
    for table in ts_index.get("tables",[]):
        key="db.table."+table["physicalName"]
        owner=_module_for_file(table["file"],modules)
        actual.append(dict(table,ownershipKey=key,module=owner))
        if owner:
            if key not in declared:
                raise RegistryFailure(f"DATA-001: Drizzle table {key} in module {owner} is not declared in module data.owns")
            if declared[key] != owner:
                raise RegistryFailure(f"DATA-001: table {key} is physically in {owner} but manifest ownership says {declared[key]}")
    for key,mid in declared.items():
        m=modules[mid][0]
        if m.get("data",{}).get("adapter") == "drizzle-postgres" and key.startswith("db.table.") and not any(x["ownershipKey"]==key for x in actual):
            raise RegistryFailure(f"DATA-001: module {mid} declares {key} but no Drizzle table was indexed")
    return actual


def build_repository_truth(repo: Path, root: Path, cfg: dict, modules: dict, permissions: dict, events: dict, contracts: dict, write: bool=False) -> dict:
    ts_index=build_typescript_index(repo,root,cfg)
    tables=validate_data_ownership(ts_index,modules)
    contract_list=[]
    for cid,(m,p,doc,ops) in contracts.items():
        contract_list.append({"id":cid,"owner":m["owner"],"audience":m["audience"],"stability":m["stability"],"version":m["version"],"source":m["source"],"openapi":m["openapi"],"sourceSha256":_sha256(repo/m["source"]),"operations":ops})
    data={
      "version":1,"generatedAt":datetime.now(timezone.utc).isoformat(),"repository":str(repo),
      "symbols":ts_index.get("symbols",[]),"imports":ts_index.get("imports",[]),"dataModels":tables,
      "contracts":contract_list,"permissions":list(permissions.values()),"events":list(events.values())
    }
    truth_schema=load_data(root/cfg["schemas"]["repositoryTruth"])
    errors=sorted(Draft202012Validator(truth_schema).iter_errors(data), key=lambda e:list(e.absolute_path))
    if errors:
        raise RegistryFailure("Repository Truth schema invalid: " + "; ".join(e.message for e in errors[:5]))
    if write:
        out=repo/cfg.get("repositoryTruth",{}).get("output",".governance/repository-truth.json")
        dump_json(out,data)
    return data


def symbol_keys(truth: dict) -> set[str]:
    keys=set()
    for s in truth.get("symbols",[]):
        keys.add(s.get("name",""))
        if s.get("kind")=="class":
            for m in s.get("members",[]): keys.add(f"{s['name']}.{m.get('name')}")
    return {k for k in keys if k}


def contract_operation_keys(truth: dict) -> set[str]:
    out=set()
    for c in truth.get("contracts",[]):
        out.add(c["id"])
        for op in c.get("operations",[]): out.add(f"{c['id']}#{op['operationId']}")
    return out
