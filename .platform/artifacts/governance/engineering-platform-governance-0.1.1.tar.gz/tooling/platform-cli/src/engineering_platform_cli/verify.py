from __future__ import annotations
from pathlib import Path
from dataclasses import dataclass
from .patterns import matches_any
from .dependencies import package_dependencies_changed
from .risk import infer_minimum_risk, risk_index
from .ui_checks import load_ui_policy, scan_ui_file
from .git_utils import show_file
from .io_utils import load_data
from .repository_truth import load_api_contracts
from .contract_safety import breaking_changes, destructive_migration_findings
import yaml


@dataclass
class Finding:
    rule: str
    message: str
    path: str | None = None
    severity: str = "blocking"

    def as_dict(self):
        return {"rule": self.rule, "message": self.message, "path": self.path, "severity": self.severity}


def verify_task(task: dict, changes, repo: Path, cfg: dict, known_rules: set[str], platform_root: Path | None = None) -> tuple[list[Finding], dict]:
    findings: list[Finding] = []
    scope = task["scope"]
    changed_paths = [c.path for c in changes]

    for gate in task.get("requiredGates", []) or []:
        if gate not in known_rules:
            findings.append(Finding("GOV-001", f"Unknown required gate id: {gate}"))

    for assumption in task.get("assumptions", []):
        if assumption.get("status") != "verified":
            findings.append(Finding("ASM-001", f"Blocked assumption: {assumption.get('statement','')}") )

    control_paths = cfg.get("controlPaths", [])
    for c in changes:
        path = c.path
        if matches_any(path, control_paths):
            continue
        if matches_any(path, scope.get("forbiddenPaths", [])):
            findings.append(Finding("SCP-001", "Changed file matches a forbidden path", path))
        if not matches_any(path, scope.get("allowedPaths", [])):
            findings.append(Finding("SCP-001", "Changed file is outside allowedPaths", path))
        if c.status == "A":
            if not scope.get("allowNewFiles", False):
                findings.append(Finding("SCP-002", "New file is not allowed by task scope", path))
            elif scope.get("allowedNewFiles") and not matches_any(path, scope.get("allowedNewFiles", [])):
                findings.append(Finding("SCP-002", "New file is not in allowedNewFiles", path))
        if task["mode"] == "fix" and c.status == "R":
            findings.append(Finding("FIX-001", "Fix tasks may not rename/move files incidentally", path))

        classes = cfg.get("pathClasses", {})
        if matches_any(path, classes.get("dependencyManifests", [])) and package_dependencies_changed(repo, task["baseRevision"], path):
            if not scope.get("allowDependencies", False):
                findings.append(Finding("DEP-001", "Dependency change is not allowed", path))
        if matches_any(path, classes.get("migrations", [])) and not scope.get("allowMigrations", False):
            findings.append(Finding("MIG-001", "Migration change is not allowed", path))
        if matches_any(path, classes.get("publicContracts", [])) and not scope.get("allowPublicContractChanges", False):
            findings.append(Finding("API-001", "Public contract change is not allowed", path))
        if matches_any(path, classes.get("platformChanges", [])) and not scope.get("allowPlatformChanges", False):
            findings.append(Finding("PLT-001", "Platform/shared path change is not allowed", path))
        if matches_any(path, classes.get("architectureChanges", [])) and not scope.get("allowArchitectureChanges", False):
            findings.append(Finding("ARCH-001", "Architecture change is not allowed", path))
        if matches_any(path, classes.get("controlPlane", [])):
            if not scope.get("allowControlPlaneChanges", False):
                findings.append(Finding("TRUST-001", "Control-plane change is not explicitly authorized", path))
            if task.get("mode") not in {"platform-change", "security-change"} or risk_index(cfg, task.get("risk","R0")) < risk_index(cfg,"R4"):
                findings.append(Finding("TRUST-001", "Control-plane changes require R4 platform-change/security-change mode", path))
        if matches_any(path, classes.get("trustRoot", [])):
            if not scope.get("allowTrustRootChanges", False):
                findings.append(Finding("TRUST-002", "Trust-root change is not explicitly authorized", path))
            if task.get("mode") not in {"platform-change", "security-change"} or risk_index(cfg, task.get("risk","R0")) < risk_index(cfg,"R4"):
                findings.append(Finding("TRUST-002", "Trust-root changes require R4 platform-change/security-change mode", path))
        if matches_any(path, classes.get("visualBaselines", [])) and not scope.get("allowVisualBaselineChanges", False):
            findings.append(Finding("UI-012", "Visual baseline change is not explicitly allowed by task scope", path))

    # UI policy is derived from the actual changed files, not from an agent declaration.
    policy_base = platform_root or repo
    policy_path = policy_base / cfg.get("uiPolicy", "tooling/policies/ui-policy.yaml")
    if policy_path.exists():
        from .io_utils import load_data
        ui_policy = load_data(policy_path)
        for c in changes:
            for item in scan_ui_file(repo, c.path, ui_policy):
                findings.append(Finding(item["rule"], item["message"], item["path"]))

    # Contract source/generated-artifact integrity and compatibility.
    policy_root = platform_root or repo
    try:
        contracts = load_api_contracts(repo, policy_root, cfg)
    except Exception as exc:
        findings.append(Finding("API-003", str(exc)))
        contracts = {}
    changed=set(changed_paths)
    for cid,(manifest,_mp,_doc,_ops) in contracts.items():
        source=manifest["source"]; generated=manifest["openapi"]
        source_changed=source in changed
        generated_changed=generated in changed
        if generated_changed and not source_changed:
            findings.append(Finding("API-003", f"Generated OpenAPI changed without its TypeSpec source for {cid}", generated))
        if source_changed and not generated_changed:
            # load_api_contracts normally catches stale source hash; make the diff reason explicit too.
            findings.append(Finding("API-003", f"TypeSpec source changed without regenerated OpenAPI for {cid}", source))
        if generated_changed:
            old_text=show_file(repo, task["baseRevision"], generated)
            current_path=repo/generated
            if old_text is not None and current_path.exists():
                try:
                    old_doc=yaml.safe_load(old_text) or {}
                    new_doc=load_data(current_path)
                    breaks=breaking_changes(old_doc,new_doc)
                    if breaks and not task.get("scope",{}).get("allowBreakingContractChanges",False):
                        findings.append(Finding("API-002", "Breaking API changes detected: " + "; ".join(breaks[:8]), generated))
                    elif breaks and risk_index(cfg, task["risk"]) < risk_index(cfg,"R3"):
                        findings.append(Finding("API-002", "Breaking API changes require at least R3 risk", generated))
                except Exception as exc:
                    findings.append(Finding("API-002", f"Unable to compare API compatibility: {exc}", generated))
    # Deleted public contract artifacts are breaking by definition.
    for c in changes:
        if c.status == "D" and matches_any(c.path, cfg.get("pathClasses",{}).get("publicContracts",[])):
            if not task.get("scope",{}).get("allowBreakingContractChanges",False):
                findings.append(Finding("API-002", "Deleting a public contract artifact is a breaking change", c.path))

    # Migration history is immutable; allowed new/modified migrations still receive destructive-operation screening.
    for c in changes:
        if not matches_any(c.path, cfg.get("pathClasses",{}).get("migrations",[])):
            continue
        existed_at_base = show_file(repo, task["baseRevision"], c.path) is not None
        if c.status in {"D","R"} or (c.status == "M" and existed_at_base):
            findings.append(Finding("MIG-002", "Existing migration history is immutable and may not be modified, deleted, or renamed", c.path))
            continue
        current=repo/c.path
        if current.exists() and current.is_file():
            try:
                text=current.read_text(encoding="utf-8",errors="ignore")
            except Exception:
                text=""
            destructive=destructive_migration_findings(text)
            if destructive:
                if not task.get("scope",{}).get("allowDestructiveMigrations",False):
                    findings.append(Finding("DB-001", "Destructive migration operations require explicit allowDestructiveMigrations: " + ", ".join(destructive), c.path))
                elif risk_index(cfg, task["risk"]) < risk_index(cfg,"R4"):
                    findings.append(Finding("DB-001", "Destructive migrations require R4 risk", c.path))

    minimum_risk, risk_reasons = infer_minimum_risk(task, changed_paths, cfg)
    if risk_index(cfg, task["risk"]) < risk_index(cfg, minimum_risk):
        findings.append(Finding("RISK-001", f"Declared risk {task['risk']} is lower than inferred minimum {minimum_risk}"))

    metadata = {
        "declaredRisk": task["risk"],
        "minimumRisk": minimum_risk,
        "riskReasons": risk_reasons,
        "changedFiles": [{"status": c.status, "path": c.path, "oldPath": c.old_path} for c in changes]
    }
    return findings, metadata
