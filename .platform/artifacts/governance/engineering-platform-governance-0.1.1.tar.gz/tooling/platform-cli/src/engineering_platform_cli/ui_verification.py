from __future__ import annotations
from pathlib import Path
import fnmatch
import subprocess
import sys
from .contracts import validate_document
from .verify import Finding


def find_manifests(repo: Path, root: Path, cfg: dict) -> list[Path]:
    names=set(cfg.get('uiVerification',{}).get('manifestNames',[]))
    ignored={'node_modules','.git','.nx','.agent-context','.governance'}
    paths=[]
    for base in ([root] if repo.resolve()==root.resolve() else [root,repo]):
        for p in base.rglob('*'):
            if p.name in names and not any(x in ignored for x in p.parts): paths.append(p)
    # de-duplicate when repo==root / overlapping roots
    return sorted({p.resolve() for p in paths})


def load_manifests(repo: Path, root: Path, cfg: dict):
    schema=root/cfg['schemas']['uiVerification']; result=[]; ids=set()
    for path in find_manifests(repo,root,cfg):
        data=validate_document(path,schema)
        if data['id'] in ids: raise RuntimeError(f"Duplicate UI verification id: {data['id']}")
        ids.add(data['id']); result.append((data,path))
    return result


def _match(path:str,pattern:str): return fnmatch.fnmatchcase(path.replace('\\','/'),pattern.replace('\\','/'))


def affected_manifests(repo: Path, root: Path, cfg: dict, changed_paths: list[str]):
    out=[]
    for data,path in load_manifests(repo,root,cfg):
        if any(_match(changed,pat) for changed in changed_paths for pat in data['sourcePatterns']): out.append((data,path))
    return out


def run_affected_ui_gates(repo:Path, root:Path, cfg:dict, changed_paths:list[str], required_gates:list[str]):
    relevant=set(required_gates) & set(cfg.get('uiVerification',{}).get('coverageRequiredWhenGates',[]))
    if not relevant: return [],[]
    manifests=affected_manifests(repo,root,cfg,changed_paths)
    findings=[]; evidence=[]
    if not manifests:
        findings.append(Finding('UI-008',f"Rendered UI gates {sorted(relevant)} were requested but no UI verification manifest covers the changed paths."))
        return findings,evidence
    runner=root/'tooling/ui-tests/run_manifest.py'
    for data,path in manifests:
        # UI-005 is strictly enforced: the manifest must opt into axe, not only smoke checks.
        if 'UI-005' in relevant and not data['checks'].get('axe',False):
            findings.append(Finding('UI-005',f"Manifest {data['id']} does not enable axe accessibility checks",str(path)))
            continue
        p=subprocess.run([sys.executable,str(runner),str(path),'--repo',str(repo)],cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        evidence.append({'id':data['id'],'manifest':str(path),'returnCode':p.returncode,'stdout':p.stdout[-8000:],'stderr':p.stderr[-4000:]})
        if p.returncode!=0:
            # One rendered run covers UI-003/004/005/006 according to its configured checks.
            for gate,flag in [('UI-003','responsive'),('UI-004','direction'),('UI-005','axe'),('UI-006','visual')]:
                if gate in relevant and data['checks'].get(flag,False): findings.append(Finding(gate,f"Rendered UI verification failed for {data['id']}",str(path)))
    return findings,evidence
