from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import hashlib
import json
import subprocess
import tempfile

import yaml

from .contracts import validate_document
from .git_utils import changes, revision_exists, show_file
from .patterns import matches_any
from .risk import risk_index


@dataclass
class TrustFinding:
    rule: str
    message: str
    path: str | None = None

    def as_dict(self):
        return {"rule": self.rule, "message": self.message, "path": self.path, "severity": "blocking"}


def load_trust_policy(root: Path, cfg: dict) -> dict:
    policy_path = root / cfg.get("trustRoot", {}).get("policy", "tooling/trust-root/trust-root.yaml")
    schema_path = root / cfg.get("trustRoot", {}).get("schema", "tooling/schemas/trust-root.schema.json")
    return validate_document(policy_path, schema_path)


def _load_task_at_revision(repo: Path, revision: str, task_path: str, root: Path, cfg: dict) -> dict:
    raw = show_file(repo, revision, task_path)
    if raw is None:
        raise RuntimeError(f"AUTH-001: required task contract is missing at {revision}:{task_path}")
    try:
        task = yaml.safe_load(raw) or {}
    except Exception as exc:
        raise RuntimeError(f"TASK-001: task contract cannot be parsed: {exc}") from exc
    # Validate candidate task data with the trusted/base schema, never a schema supplied by the PR.
    schema = root / cfg["schemas"]["task"]
    with tempfile.NamedTemporaryFile("w", suffix=".yaml", delete=False, encoding="utf-8") as fh:
        yaml.safe_dump(task, fh, sort_keys=False)
        tmp = Path(fh.name)
    try:
        validate_document(tmp, schema)
    finally:
        tmp.unlink(missing_ok=True)
    return task


def task_digest(task: dict) -> str:
    canonical = json.dumps(task, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def verify_control_plane(repo: Path, root: Path, cfg: dict, base: str, head: str) -> tuple[list[TrustFinding], dict]:
    if not revision_exists(repo, base):
        raise RuntimeError(f"BASE-001: trusted base revision does not exist: {base}")
    if not revision_exists(repo, head):
        raise RuntimeError(f"BASE-001: candidate head revision does not exist: {head}")

    policy = load_trust_policy(root, cfg)
    task = _load_task_at_revision(repo, head, policy["taskPath"], root, cfg)
    findings: list[TrustFinding] = []

    if task.get("baseRevision") != base:
        findings.append(TrustFinding("BASE-001", f"Task baseRevision {task.get('baseRevision')} does not match trusted PR base {base}", policy["taskPath"]))

    ch = changes(repo, base, head)
    changed_paths = [c.path for c in ch]
    scope = task.get("scope", {})
    control = [p for p in changed_paths if matches_any(p, policy.get("controlPlanePaths", []))]
    trust = [p for p in changed_paths if matches_any(p, policy.get("trustRootPaths", []))]
    proof = [p for p in changed_paths if matches_any(p, policy.get("proofAssetPaths", []))]

    if control:
        if not scope.get("allowControlPlaneChanges", False):
            for p in control:
                findings.append(TrustFinding("TRUST-001", "Control-plane changes require explicit approved authority", p))
        if task.get("mode") not in policy.get("allowedControlPlaneModes", ["platform-change", "security-change"]):
            findings.append(TrustFinding("TRUST-001", f"Control-plane changes require mode in {policy.get('allowedControlPlaneModes')}", None))
        if risk_index(cfg, task.get("risk", "R0")) < risk_index(cfg, policy["minimumRisk"]["controlPlane"]):
            findings.append(TrustFinding("TRUST-001", f"Control-plane changes require at least {policy['minimumRisk']['controlPlane']} risk", None))

    if trust:
        if not scope.get("allowTrustRootChanges", False):
            for p in trust:
                findings.append(TrustFinding("TRUST-002", "Trust-root bootstrap changes require explicit approved authority", p))
        if task.get("mode") not in policy.get("allowedTrustRootModes", ["platform-change", "security-change"]):
            findings.append(TrustFinding("TRUST-002", f"Trust-root changes require mode in {policy.get('allowedTrustRootModes')}", None))
        if risk_index(cfg, task.get("risk", "R0")) < risk_index(cfg, policy["minimumRisk"]["trustRoot"]):
            findings.append(TrustFinding("TRUST-002", f"Trust-root changes require at least {policy['minimumRisk']['trustRoot']} risk", None))

    if proof:
        if not scope.get("allowVisualBaselineChanges", False):
            for p in proof:
                findings.append(TrustFinding("TRUST-003", "Reviewed proof/baseline asset change is not authorized", p))
        if risk_index(cfg, task.get("risk", "R0")) < risk_index(cfg, policy["minimumRisk"]["proofAsset"]):
            findings.append(TrustFinding("TRUST-003", f"Proof/baseline changes require at least {policy['minimumRisk']['proofAsset']} risk", None))

    metadata = {
        "base": base,
        "head": head,
        "taskId": task.get("id"),
        "taskDigest": task_digest(task),
        "controlPlaneChanges": control,
        "trustRootChanges": trust,
        "proofAssetChanges": proof,
        "changedFiles": changed_paths,
        "requiredExternalControls": policy.get("requiredExternalControls", []),
    }
    return findings, metadata


def extract_trusted_bundle(repo: Path, base: str, output: Path) -> Path:
    """Export the verifier/policy sources from a trusted base revision.

    This allows CI to install/run the verifier that existed on the trusted base,
    rather than installing the candidate verifier from the pull request.
    """
    requested = [
        "tooling/platform-cli",
        "tooling/governance.config.yaml",
        "tooling/registry",
        "tooling/schemas",
        "tooling/policies",
        "tooling/trust-root",
    ]
    tree = subprocess.run(["git", "ls-tree", "-r", "--name-only", base], cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if tree.returncode != 0:
        raise RuntimeError(f"Unable to inspect trusted base: {tree.stderr.strip()}")
    files = tree.stdout.splitlines()
    paths = []
    for item in requested:
        if item in files or any(f.startswith(item.rstrip("/") + "/") for f in files):
            paths.append(item)
    if not paths:
        raise RuntimeError("Trusted base contains none of the verifier/policy paths required for extraction")
    output.mkdir(parents=True, exist_ok=True)
    cmd = ["git", "archive", "--format=tar", base, *paths]
    p1 = subprocess.Popen(cmd, cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    p2 = subprocess.run(["tar", "-xf", "-", "-C", str(output)], stdin=p1.stdout, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p1.stdout:
        p1.stdout.close()
    stderr = p1.stderr.read().decode("utf-8", errors="replace") if p1.stderr else ""
    rc = p1.wait()
    if rc != 0 or p2.returncode != 0:
        raise RuntimeError(f"Unable to extract trusted verifier bundle: {stderr or p2.stderr.decode(errors='replace')}")
    return output
