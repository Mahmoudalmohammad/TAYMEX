from __future__ import annotations
from pathlib import Path
import fnmatch
import re
from .io_utils import load_data

IMPORT_RE = re.compile(r"(?:from\s+|import\s*\(\s*)['\"]([^'\"]+)['\"]")
RAW_COLOR_RE = re.compile(r"#[0-9a-fA-F]{3,8}\b|\b(?:rgb|rgba|hsl|hsla|oklch|oklab)\s*\(")
PANDA_ESCAPE_RE = re.compile(r"['\"]\[[^\]\n]+\]['\"]")
RAW_VISUAL_RE = re.compile(r"\b(?:borderRadius|boxShadow|fontSize|fontFamily)\s*[:=]\s*['\"][^'\"]+['\"]|\b(?:border-radius|box-shadow|font-size|font-family)\s*:\s*[^;}{]+", re.IGNORECASE)
INLINE_STYLE_RE = re.compile(r"\bstyle\s*=\s*\{\{", re.MULTILINE)
PHYSICAL_DIR_RE = re.compile(
    r"\b(?:marginLeft|marginRight|paddingLeft|paddingRight|borderLeft|borderRight|"
    r"borderLeftWidth|borderRightWidth|insetLeft|insetRight|left|right)\s*[:=]"
)
NATIVE_TAG_RE_TEMPLATE = r"<\s*(?:{tags})\b"


def _matches(path: str, pattern: str) -> bool:
    return fnmatch.fnmatchcase(path.replace('\\', '/'), pattern.replace('\\', '/'))


def _matches_any(path: str, patterns: list[str] | None) -> bool:
    return any(_matches(path, p) for p in (patterns or []))


def _import_matches(value: str, pattern: str) -> bool:
    if '*' in pattern:
        return fnmatch.fnmatchcase(value, pattern)
    return value == pattern or value.startswith(pattern + '/')


def load_ui_policy(root: Path, cfg: dict) -> dict:
    rel = cfg.get('uiPolicy', 'tooling/policies/ui-policy.yaml')
    return load_data(root / rel)


def is_governed_ui_path(path: str, policy: dict) -> bool:
    p = path.replace('\\', '/')
    if Path(p).suffix not in set(policy.get('scanExtensions', [])):
        return False
    root = p.split('/', 1)[0]
    if root not in set(policy.get('scanRoots', [])):
        return False
    if _matches_any(p, policy.get('exemptPaths', [])):
        return False
    return True


def scan_ui_file(repo: Path, path: str, policy: dict) -> list[dict]:
    if not is_governed_ui_path(path, policy):
        return []
    file_path = repo / path
    if not file_path.exists() or not file_path.is_file():
        return []
    try:
        text = file_path.read_text(encoding='utf-8')
    except UnicodeDecodeError:
        return []

    findings: list[dict] = []

    # Equivalent shared UI must not be bypassed via raw/native primitives.
    tags = policy.get('forbiddenNativePrimitives', [])
    if tags and re.search(NATIVE_TAG_RE_TEMPLATE.format(tags='|'.join(map(re.escape, tags))), text):
        findings.append({'rule': 'UI-001', 'message': 'Native interactive primitive is forbidden in governed product UI; use the platform component.', 'path': path})

    stem = file_path.name.split('.')[0]
    if stem in set(policy.get('forbiddenSharedComponentNames', [])):
        findings.append({'rule': 'UI-001', 'message': f'Local shared-primitive clone name {stem} is forbidden; extend/reuse the canonical platform component.', 'path': path})

    for imported in IMPORT_RE.findall(text):
        for forbidden in policy.get('forbiddenThirdPartyUiImports', []):
            if _import_matches(imported, forbidden):
                findings.append({'rule': 'UI-002', 'message': f'Direct UI/styling dependency import is forbidden outside the platform UI layer: {imported}', 'path': path})
                break

    if policy.get('forbidRawColors', True) and RAW_COLOR_RE.search(text):
        findings.append({'rule': 'UI-002', 'message': 'Raw color value detected; use a semantic design token.', 'path': path})
    if policy.get('forbidRawPandaEscapes', True) and PANDA_ESCAPE_RE.search(text):
        findings.append({'rule': 'UI-002', 'message': 'Raw Panda escape value detected; use a governed token/recipe.', 'path': path})
    if policy.get('forbidRawRadiusShadowTypography', True) and RAW_VISUAL_RE.search(text):
        findings.append({'rule': 'UI-002', 'message': 'Raw radius/shadow/typography value detected; use a governed component/token.', 'path': path})
    if policy.get('forbidInlineStyle', True) and INLINE_STYLE_RE.search(text):
        findings.append({'rule': 'UI-002', 'message': 'Inline style object is forbidden in governed product UI.', 'path': path})
    if policy.get('forbidPhysicalDirectionProperties', True) and PHYSICAL_DIR_RE.search(text):
        findings.append({'rule': 'UI-002', 'message': 'Physical left/right styling detected; use logical direction-aware properties/patterns.', 'path': path})

    return findings
