from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
from .io_utils import dump_json, dump_text


def write_summary(repo: Path, cfg: dict, task: dict, metadata: dict, findings) -> Path:
    out = repo / cfg.get("evidenceDirectory", ".governance/evidence") / task["id"]
    passed = not any(f.severity == "blocking" for f in findings)
    payload = {
        "taskId": task["id"],
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "passed": passed,
        **metadata,
        "findings": [f.as_dict() for f in findings]
    }
    dump_json(out / "governance-summary.json", payload)
    lines = [
        f"# Governance Summary — {task['id']}",
        "",
        f"**Result:** {'PASS' if passed else 'FAIL'}",
        f"**Declared risk:** {metadata.get('declaredRisk')}",
        f"**Inferred minimum risk:** {metadata.get('minimumRisk')}",
        "",
        "## Findings",
        ""
    ]
    if findings:
        for f in findings:
            suffix = f" — `{f.path}`" if f.path else ""
            lines.append(f"- **{f.rule}**: {f.message}{suffix}")
    else:
        lines.append("- None.")
    dump_text(out / "governance-summary.md", "\n".join(lines))
    return out
