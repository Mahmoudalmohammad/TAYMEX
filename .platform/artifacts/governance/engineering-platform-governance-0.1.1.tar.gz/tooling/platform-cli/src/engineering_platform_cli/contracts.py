from __future__ import annotations
from pathlib import Path
from jsonschema import Draft202012Validator
from .io_utils import load_data


class ValidationFailure(Exception):
    pass


def validate_document(document_path: Path, schema_path: Path):
    document = load_data(document_path)
    schema = load_data(schema_path)
    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(document), key=lambda e: list(e.absolute_path))
    if errors:
        lines = []
        for err in errors:
            loc = ".".join(str(p) for p in err.absolute_path) or "<root>"
            lines.append(f"{loc}: {err.message}")
        raise ValidationFailure("\n".join(lines))
    return document
