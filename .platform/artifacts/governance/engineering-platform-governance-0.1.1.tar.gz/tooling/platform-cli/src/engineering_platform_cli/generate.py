from __future__ import annotations
from pathlib import Path
import re
from .io_utils import dump_text


def _kebab(name: str) -> str:
    name = re.sub(r"([a-z0-9])([A-Z])", r"\1-\2", name)
    name = re.sub(r"[^A-Za-z0-9]+", "-", name).strip("-").lower()
    if not name:
        raise ValueError("Invalid name")
    return name


def generate_module(repo: Path, name: str, layer: str, owner: str) -> Path:
    slug = _kebab(name)
    base_dir = "capabilities" if layer == "capability" else "packages"
    target = repo / base_dir / slug
    if target.exists() and any(target.iterdir()):
        raise RuntimeError(f"Target already exists and is not empty: {target}")
    (target / "src").mkdir(parents=True, exist_ok=True)
    manifest = f"""id: {slug}\nlayer: {layer}\nowner: {owner}\ntags:\n  - layer:{layer}\n  - type:domain\ndependencies:\n  allowedModules: []\n  allowedTags:\n    - layer:kernel\ndata:\n  owns: []\n  readsViaContracts: []\n  classification: internal\nsettings:\n  defines: []\n  consumes: []\npermissions:\n  defines: []\n  consumes: []\nevents:\n  emits: []\n  consumes: []\ncontracts:\n  owns: []\n  consumes: []\nsecurityTags: []\nperformanceTags: []\nextensionModes:\n  - USE\n  - EXTEND\n"""
    dump_text(target / "module.manifest.yaml", manifest)
    dump_text(target / "src" / "index.ts", "// Public API only. Add exports deliberately; do not expose module internals by default.\n")
    dump_text(target / "README.md", f"# {slug}\n\nGenerated through the governed platform module generator.\n")
    dump_text(target / "project.json", f'''{{\n  "name": "{slug}",\n  "sourceRoot": "{base_dir}/{slug}/src",\n  "projectType": "library",\n  "tags": ["layer:{layer}", "type:domain"]\n}}\n''')
    return target


def generate_ui_primitive(repo: Path, name: str) -> Path:
    slug = _kebab(name)
    comp = "".join(part.capitalize() for part in slug.split("-"))
    target = repo / "packages" / "ui" / "src" / "primitives" / slug
    if target.exists() and any(target.iterdir()):
        raise RuntimeError(f"Target already exists and is not empty: {target}")
    target.mkdir(parents=True, exist_ok=True)
    component = f"export interface {comp}Props {{\n  // Define semantics first. Third-party interaction primitives may be wrapped only here.\n}}\n\nexport function {comp}(_props: {comp}Props) {{\n  throw new Error('{comp} requires an approved design-system implementation task before use.');\n}}\n"
    dump_text(target / f"{comp}.tsx", component)
    dump_text(target / "index.ts", f"export * from './{comp}';\n")
    story = f"import type {{ Meta, StoryObj }} from '@storybook/react';\nimport {{ {comp} }} from './{comp}';\nconst meta = {{ component: {comp}, title: 'Primitives/{comp}', tags: ['autodocs'] }} satisfies Meta<typeof {comp}>;\nexport default meta;\ntype Story = StoryObj<typeof meta>;\nexport const Default: Story = {{ args: {{}} }};\n"
    dump_text(target / f"{comp}.stories.tsx", story)
    manifest = f"id: ui.{slug}\nname: {comp}\ncategory: primitive\npackage: '@engineering-platform/ui'\nexport: {comp}\ncanonicalRoles: [primitive.{slug}]\nstatus: experimental\nrequiredStates: [default, focus, disabled]\nstories: [{comp}.stories.tsx]\n"
    dump_text(target / "component.manifest.yaml", manifest)
    return target

def generate_admin_crud_page(repo: Path, name: str, target_root: str) -> Path:
    slug = _kebab(name)
    root = (repo / target_root / slug).resolve()
    try:
        root.relative_to(repo.resolve())
    except ValueError:
        raise RuntimeError("Generated page target must stay inside the repository")
    normalized = root.relative_to(repo.resolve()).as_posix()
    if not normalized.startswith(("apps/", "examples/")):
        raise RuntimeError("Admin CRUD page generator target must be under apps/ or examples/")
    if root.exists() and any(root.iterdir()):
        raise RuntimeError(f"Target already exists and is not empty: {root}")
    root.mkdir(parents=True, exist_ok=True)
    comp = "".join(part.capitalize() for part in slug.split("-")) + "Page"
    body = f"""import {{ Button, TextField }} from '@engineering-platform/ui';
import {{ CrudPage, PageState }} from '@engineering-platform/ui-patterns';

export interface {comp}Props {{
  state?: 'loading' | 'empty' | 'error' | 'success';
}}

export function {comp}({{ state = 'success' }}: {comp}Props) {{
  const content = state === 'success'
    ? <div data-domain-content>{slug} data region</div>
    : <PageState kind={{state}} title={{state === 'loading' ? 'Loading' : state === 'empty' ? 'No results' : 'Unable to load'}} />;

  return <CrudPage
    title=\"{name}\"
    actions={{<Button>Add</Button>}}
    filters={{<TextField label=\"Search\" />}}
    content={{content}}
  />;
}}
"""
    dump_text(root / "page.tsx", body)
    dump_text(root / "README.md", "Generated from the governed admin CRUD pattern. Domain code may extend content and behavior but must not replace shared UI primitives.\n")
    return root


def _page_target(repo: Path, name: str, target_root: str) -> tuple[Path, str, str]:
    slug = _kebab(name)
    root = (repo / target_root / slug).resolve()
    try:
        root.relative_to(repo.resolve())
    except ValueError:
        raise RuntimeError("Generated page target must stay inside the repository")
    normalized = root.relative_to(repo.resolve()).as_posix()
    if not normalized.startswith(("apps/", "examples/")):
        raise RuntimeError("Generated page target must be under apps/ or examples/")
    if root.exists() and any(root.iterdir()):
        raise RuntimeError(f"Target already exists and is not empty: {root}")
    root.mkdir(parents=True, exist_ok=True)
    comp = "".join(part.capitalize() for part in slug.split("-")) + "Page"
    return root, slug, comp


def generate_page_pattern(repo: Path, name: str, target_root: str, pattern: str) -> Path:
    root, slug, comp = _page_target(repo, name, target_root)
    if pattern == "form":
        body = f"""import {{ Button, TextField }} from '@engineering-platform/ui';
import {{ FormPage }} from '@engineering-platform/ui-patterns';

export function {comp}() {{
  return <FormPage title=\"{name}\" description=\"Complete the required information.\" actions={{<Button>Save</Button>}}>
    <TextField label=\"Name\" />
    <TextField label=\"Reference\" />
  </FormPage>;
}}
"""
    elif pattern == "settings":
        body = f"""import {{ Button, TextField }} from '@engineering-platform/ui';
import {{ SettingsPage }} from '@engineering-platform/ui-patterns';

export function {comp}() {{
  return <SettingsPage title=\"{name}\" description=\"Configure this area.\" search={{<TextField label=\"Search settings\" />}} actions={{<Button>Save changes</Button>}}>
    <section data-ep-settings-group aria-labelledby=\"general-settings\"><h2 id=\"general-settings\">General</h2><p>Register typed setting controls here.</p></section>
  </SettingsPage>;
}}
"""
    elif pattern == "search":
        body = f"""import {{ Button, TextField }} from '@engineering-platform/ui';
import {{ PageState, SearchPage }} from '@engineering-platform/ui-patterns';

export function {comp}() {{
  return <SearchPage title=\"{name}\" query={{<TextField label=\"Search\" />}} filters={{<div>Domain filters</div>}} actions={{<Button variant=\"secondary\">Clear filters</Button>}} results={{<PageState kind=\"empty\" title=\"No results\" description=\"Adjust the search or filters.\" />}} />;
}}
"""
    elif pattern == "details":
        body = f"""import {{ Button, Card }} from '@engineering-platform/ui';
import {{ DetailsPage }} from '@engineering-platform/ui-patterns';

export function {comp}() {{
  return <DetailsPage title=\"{name}\" subtitle=\"Entity details\" actions={{<Button>Edit</Button>}} summary={{<Card>Summary</Card>}}><Card>Details content</Card></DetailsPage>;
}}
"""
    else:
        raise RuntimeError(f"Unknown page pattern: {pattern}")
    dump_text(root / "page.tsx", body)
    dump_text(root / "README.md", f"Generated from the governed {pattern} page pattern. Extend domain content; do not replace shared primitives or structural patterns.\n")
    return root
