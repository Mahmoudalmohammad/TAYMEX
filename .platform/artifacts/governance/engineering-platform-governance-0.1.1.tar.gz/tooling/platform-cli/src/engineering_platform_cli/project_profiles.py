from __future__ import annotations
from pathlib import Path
from .contracts import validate_document, ValidationFailure


def load_project_profile(path: Path, root: Path, cfg: dict) -> dict:
    schema = root / cfg["schemas"]["projectProfile"]
    data = validate_document(path, schema)
    enabled = set(data["localization"]["enabledLocales"])
    default = data["localization"]["defaultLocale"]
    rtl = set(data["localization"]["rtlLocales"])
    if default not in enabled:
        raise ValidationFailure(f"localization.defaultLocale {default} is not in enabledLocales")
    unknown_rtl = sorted(rtl - enabled)
    if unknown_rtl:
        raise ValidationFailure("localization.rtlLocales contains locales not enabled: " + ", ".join(unknown_rtl))
    scopes = set(data["settings"]["enabledScopes"])
    if data["settings"]["tenantScope"] and "tenant" not in scopes:
        raise ValidationFailure("settings.tenantScope=true requires tenant in enabledScopes")
    if not data["settings"]["tenantScope"] and "tenant" in scopes:
        raise ValidationFailure("tenant scope is disabled but tenant is present in enabledScopes")
    tenancy = data.get("capabilities", {}).get("tenancy")
    if tenancy == "enabled" and not data["settings"]["tenantScope"]:
        raise ValidationFailure("capabilities.tenancy=enabled requires settings.tenantScope=true")
    if tenancy == "disabled" and data["settings"]["tenantScope"]:
        raise ValidationFailure("capabilities.tenancy=disabled conflicts with settings.tenantScope=true")
    return data


def find_project_profiles(root: Path) -> list[Path]:
    directory = root / "blueprints" / "project-profiles"
    if not directory.exists():
        return []
    return sorted(p for p in directory.glob("*.yaml") if p.is_file())
