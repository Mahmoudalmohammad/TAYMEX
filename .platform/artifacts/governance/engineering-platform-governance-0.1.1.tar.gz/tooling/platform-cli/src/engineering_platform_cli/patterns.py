from __future__ import annotations
import fnmatch


def matches(path: str, pattern: str) -> bool:
    path = path.replace("\\", "/").lstrip("./")
    pattern = pattern.replace("\\", "/").lstrip("./")
    return fnmatch.fnmatchcase(path, pattern)


def matches_any(path: str, patterns: list[str] | None) -> bool:
    return any(matches(path, p) for p in (patterns or []))
