from __future__ import annotations
from pathlib import Path
import json
import tomllib
from .git_utils import show_file

JS_SECTIONS = ["dependencies", "devDependencies", "peerDependencies", "optionalDependencies"]


def _js_deps(text: str | None):
    if text is None:
        return None
    obj = json.loads(text)
    return {section: obj.get(section, {}) for section in JS_SECTIONS}


def package_dependencies_changed(repo: Path, base: str, path: str) -> bool:
    current_path = repo / path
    if path.endswith("package.json"):
        before = _js_deps(show_file(repo, base, path))
        after = _js_deps(current_path.read_text(encoding="utf-8")) if current_path.exists() else None
        return before != after
    if path.endswith("pyproject.toml"):
        before_text = show_file(repo, base, path)
        before = tomllib.loads(before_text) if before_text else {}
        after = tomllib.loads(current_path.read_text(encoding="utf-8")) if current_path.exists() else {}
        def dep_view(x):
            project = x.get("project", {})
            poetry = x.get("tool", {}).get("poetry", {})
            return {
                "dependencies": project.get("dependencies", []),
                "optional": project.get("optional-dependencies", {}),
                "poetry": poetry.get("dependencies", {}),
                "poetryDev": poetry.get("group", {}).get("dev", {}).get("dependencies", {})
            }
        return dep_view(before) != dep_view(after)
    if path.endswith(("pnpm-lock.yaml", "yarn.lock", "package-lock.json")):
        return True
    return False
