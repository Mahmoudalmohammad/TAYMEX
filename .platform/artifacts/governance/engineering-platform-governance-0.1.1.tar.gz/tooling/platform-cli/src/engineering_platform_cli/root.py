from __future__ import annotations
from pathlib import Path


def find_root(start: Path | None = None) -> Path:
    current = (start or Path.cwd()).resolve()
    for candidate in [current, *current.parents]:
        if (candidate / "tooling" / "governance.config.yaml").exists():
            return candidate
    raise RuntimeError("Could not locate engineering platform/project governance root (tooling/governance.config.yaml missing).")
