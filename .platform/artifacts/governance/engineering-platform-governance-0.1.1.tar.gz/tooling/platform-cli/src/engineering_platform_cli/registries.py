from __future__ import annotations
from pathlib import Path
from .contracts import validate_document, ValidationFailure
from .io_utils import load_data


class RegistryFailure(Exception):
    pass


def load_rules(root: Path, cfg: dict) -> dict[str, dict]:
    path = root / cfg["registries"]["rules"]
    validate_document(path, root / cfg["schemas"]["rules"])
    data = load_data(path)
    rules = {}
    for rule in data.get("rules", []):
        rid = rule["id"]
        if rid in rules:
            raise RegistryFailure(f"Duplicate rule id: {rid}")
        rules[rid] = rule
    return rules


def load_settings(root: Path, cfg: dict) -> dict[str, dict]:
    path = root / cfg["registries"]["settings"]
    validate_document(path, root / cfg["schemas"]["settings"])
    data = load_data(path)
    by_key: dict[str, dict] = {}
    aliases: dict[str, str] = {}
    for item in data.get("settings", []):
        key = item["key"]
        if key in by_key:
            raise RegistryFailure(f"Duplicate setting key: {key}")
        if key in aliases:
            raise RegistryFailure(f"Setting key collides with alias: {key}")
        resolution = item.get("resolution")
        scopes = item.get("scopes", []) or []
        precedence = item.get("precedence")
        if resolution in {"OVERRIDE", "REPLACE"}:
            if not precedence:
                raise RegistryFailure(f"Setting {key} requires explicit precedence for {resolution}")
            if len(precedence) != len(set(precedence)) or set(precedence) != set(scopes):
                raise RegistryFailure(f"Setting {key} precedence must contain exactly its allowed scopes")
        elif precedence:
            raise RegistryFailure(f"Setting {key} declares precedence but resolution {resolution} does not use it")
        by_key[key] = item
        for alias in item.get("aliases", []) or []:
            if alias in by_key or alias in aliases:
                raise RegistryFailure(f"Duplicate/colliding setting alias: {alias}")
            aliases[alias] = key
    return by_key


def load_terminology(root: Path, cfg: dict) -> dict[str, dict]:
    path = root / cfg["registries"]["terminology"]
    validate_document(path, root / cfg["schemas"]["terminology"])
    data = load_data(path)
    terms = {}
    forbidden = {}
    for item in data.get("terms", []):
        canonical = item["canonical"]
        if canonical in terms:
            raise RegistryFailure(f"Duplicate canonical term: {canonical}")
        terms[canonical] = item
        for alias in item.get("forbiddenAliases", []) or []:
            if alias in forbidden:
                raise RegistryFailure(f"Duplicate forbidden terminology alias: {alias}")
            forbidden[alias] = canonical
    return terms



def load_permissions(root: Path, cfg: dict) -> dict[str, dict]:
    path = root / cfg["registries"]["permissions"]
    validate_document(path, root / cfg["schemas"]["permissions"])
    data = load_data(path)
    out = {}
    for item in data.get("permissions", []):
        key = item["key"]
        if key in out:
            raise RegistryFailure(f"Duplicate permission key: {key}")
        out[key] = item
    return out


def load_events(root: Path, cfg: dict) -> dict[str, dict]:
    path = root / cfg["registries"]["events"]
    validate_document(path, root / cfg["schemas"]["events"])
    data = load_data(path)
    out = {}
    for item in data.get("events", []):
        eid = item["id"]
        if eid in out:
            raise RegistryFailure(f"Duplicate event id: {eid}")
        out[eid] = item
    return out


def find_module_manifests(repo: Path) -> list[Path]:
    names = {"module.manifest.yaml", "module.manifest.yml", "module.manifest.json"}
    result = []
    ignored = {"node_modules", ".git", ".nx", ".agent-context", ".governance"}
    for p in repo.rglob("*"):
        if p.name in names and not any(part in ignored for part in p.parts):
            result.append(p)
    return sorted(result)


def load_modules(repo: Path, root: Path, cfg: dict, settings: dict[str, dict], permissions: dict[str,dict] | None = None, events: dict[str,dict] | None = None, contracts: dict | None = None) -> dict[str, tuple[dict, Path]]:
    modules = {}
    for path in find_module_manifests(repo):
        data = validate_document(path, root / cfg["schemas"]["module"])
        mid = data["id"]
        if mid in modules:
            raise RegistryFailure(f"Duplicate module id {mid}: {path} and {modules[mid][1]}")
        for key in data.get("settings", {}).get("defines", []) + data.get("settings", {}).get("consumes", []):
            if key not in settings:
                raise RegistryFailure(f"Module {mid} references unknown setting {key} ({path})")
        if permissions is not None:
            for key in data.get("permissions", {}).get("defines", []) + data.get("permissions", {}).get("consumes", []):
                if key not in permissions:
                    raise RegistryFailure(f"PERM-001: module {mid} references unknown permission {key} ({path})")
            for key in data.get("permissions", {}).get("defines", []):
                if permissions[key].get("owner") != mid:
                    raise RegistryFailure(f"PERM-001: permission {key} owner is {permissions[key].get('owner')} but module {mid} declares it")
        if events is not None:
            for eid in data.get("events", {}).get("emits", []) + data.get("events", {}).get("consumes", []):
                if eid not in events:
                    raise RegistryFailure(f"EVT-001: module {mid} references unknown event {eid} ({path})")
            for eid in data.get("events", {}).get("emits", []):
                if events[eid].get("owner") != mid:
                    raise RegistryFailure(f"EVT-001: event {eid} owner is {events[eid].get('owner')} but module {mid} emits it as owner")
        if contracts is not None:
            owned_contracts=data.get("contracts", {}).get("owns", [])
            consumed_contracts=data.get("contracts", {}).get("consumes", [])
            for cid in owned_contracts + consumed_contracts:
                if cid not in contracts:
                    raise RegistryFailure(f"API-004: module {mid} references unknown API contract {cid} ({path})")
            for cid in owned_contracts:
                if contracts[cid][0].get("owner") != mid:
                    raise RegistryFailure(f"API-004: contract {cid} owner is {contracts[cid][0].get('owner')} but module {mid} declares it")
            for cid in data.get("data",{}).get("readsViaContracts",[]) or []:
                if cid not in consumed_contracts:
                    raise RegistryFailure(f"API-004: module {mid} data.readsViaContracts includes {cid} but contracts.consumes does not declare it")
        modules[mid] = (data, path)
    return modules


def find_component_manifests(repo: Path) -> list[Path]:
    names = {"component.manifest.yaml", "component.manifest.yml", "component.manifest.json"}
    ignored = {"node_modules", ".git", ".nx", ".agent-context", ".governance"}
    result=[]
    for p in repo.rglob("*"):
        if p.name in names and not any(part in ignored for part in p.parts):
            result.append(p)
    return sorted(result)


def load_components(repo: Path, root: Path, cfg: dict) -> dict[str, tuple[dict, Path]]:
    components={}
    roles={}
    schema=root / cfg["schemas"]["component"]
    for path in find_component_manifests(repo):
        data=validate_document(path, schema)
        cid=data["id"]
        if cid in components:
            raise RegistryFailure(f"Duplicate component id {cid}: {path} and {components[cid][1]}")
        for role in data.get("canonicalRoles", []):
            if role in roles:
                raise RegistryFailure(f"Duplicate canonical UI role {role}: {path} and {roles[role]}")
            roles[role]=path
        for story in data.get("stories", []):
            if not (path.parent / story).exists():
                raise RegistryFailure(f"Component {cid} references missing Storybook story {story} ({path})")
        components[cid]=(data,path)
    return components


def load_component_catalog(repo: Path, root: Path, cfg: dict) -> dict[str, tuple[dict, Path]]:
    """Load platform UI truth plus repository-local governed UI extensions.

    A consumer project may add domain-specific component manifests, but it may not
    silently redefine an existing canonical platform role or component id.
    """
    base = load_components(root, root, cfg)
    if repo.resolve() == root.resolve():
        return base
    local = load_components(repo, root, cfg)
    merged = dict(base)
    roles = {role: path for _cid, (data, path) in base.items() for role in data.get('canonicalRoles', [])}
    for cid, item in local.items():
        data, path = item
        if cid in merged:
            raise RegistryFailure(f"Consumer component id collides with platform component {cid}: {path} and {merged[cid][1]}")
        for role in data.get('canonicalRoles', []):
            if role in roles:
                raise RegistryFailure(f"Consumer component canonical role {role} collides with platform UI role owned by {roles[role]} ({path})")
            roles[role] = path
        merged[cid] = item
    return merged
