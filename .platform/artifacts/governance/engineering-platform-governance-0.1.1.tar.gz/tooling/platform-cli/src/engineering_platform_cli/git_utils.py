from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import subprocess


@dataclass(frozen=True)
class Change:
    status: str
    path: str
    old_path: str | None = None


def _git(repo: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(["git", *args], cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=check)


def is_git_repo(repo: Path) -> bool:
    p = _git(repo, "rev-parse", "--is-inside-work-tree", check=False)
    return p.returncode == 0 and p.stdout.strip() == "true"


def revision_exists(repo: Path, rev: str) -> bool:
    return _git(repo, "rev-parse", "--verify", rev, check=False).returncode == 0


def changes(repo: Path, base: str, head: str = "HEAD") -> list[Change]:
    p = _git(repo, "diff", "--name-status", "--find-renames", f"{base}...{head}")
    result: list[Change] = []
    for raw in p.stdout.splitlines():
        if not raw.strip():
            continue
        parts = raw.split("\t")
        code = parts[0]
        if code.startswith("R") or code.startswith("C"):
            result.append(Change(code[0], parts[2], old_path=parts[1]))
        else:
            result.append(Change(code[0], parts[1]))
    return result


def show_file(repo: Path, rev: str, path: str) -> str | None:
    p = _git(repo, "show", f"{rev}:{path}", check=False)
    if p.returncode != 0:
        return None
    return p.stdout


def file_at_revision(repo: Path, revision: str, rel_path: str) -> str | None:
    return show_file(repo, revision, rel_path)
