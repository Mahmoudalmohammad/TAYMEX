from __future__ import annotations
from pathlib import Path
import re, yaml

HTTP_METHODS={"get","put","post","delete","options","head","patch","trace"}


def _params(op: dict) -> dict[tuple[str,str],dict]:
    out={}
    for p in (op or {}).get("parameters",[]) or []:
        if isinstance(p,dict) and "$ref" not in p and p.get("name") and p.get("in"):
            out[(p["in"],p["name"])]=p
    return out


def _schema_changes(old: dict, new: dict, prefix: str) -> list[str]:
    out=[]
    if not isinstance(old,dict) or not isinstance(new,dict):
        if old != new: out.append(f"{prefix}: schema shape changed")
        return out
    if old.get("type") and new.get("type") and old.get("type") != new.get("type"):
        out.append(f"{prefix}: type changed {old.get('type')} -> {new.get('type')}")
    old_enum=set(old.get("enum",[]) or []); new_enum=set(new.get("enum",[]) or [])
    removed=old_enum-new_enum
    if removed: out.append(f"{prefix}: enum values removed: {sorted(removed)}")
    old_req=set(old.get("required",[]) or []); new_req=set(new.get("required",[]) or [])
    added_required=new_req-old_req
    if added_required: out.append(f"{prefix}: required properties added: {sorted(added_required)}")
    old_props=old.get("properties",{}) or {}; new_props=new.get("properties",{}) or {}
    for k in old_props:
        if k not in new_props: out.append(f"{prefix}: property removed: {k}")
        else: out.extend(_schema_changes(old_props[k],new_props[k],f"{prefix}.{k}"))
    return out


def breaking_changes(old: dict, new: dict) -> list[str]:
    out=[]
    old_paths=old.get("paths",{}) or {}; new_paths=new.get("paths",{}) or {}
    for route,old_item in old_paths.items():
        if route not in new_paths:
            out.append(f"route removed: {route}"); continue
        new_item=new_paths[route] or {}
        for method,old_op in (old_item or {}).items():
            if method.lower() not in HTTP_METHODS: continue
            if method not in new_item:
                out.append(f"operation removed: {method.upper()} {route}"); continue
            new_op=new_item[method] or {}
            opkey=f"{method.upper()} {route}"
            op_old_params=_params(old_op); op_new_params=_params(new_op)
            for key,p in op_old_params.items():
                if key not in op_new_params: out.append(f"{opkey}: parameter removed: {key[0]}:{key[1]}")
            for key,p in op_new_params.items():
                if key not in op_old_params and p.get("required"):
                    out.append(f"{opkey}: new required parameter: {key[0]}:{key[1]}")
            if not (old_op or {}).get("requestBody",{}).get("required") and (new_op or {}).get("requestBody",{}).get("required"):
                out.append(f"{opkey}: request body became required")
            old_resp=(old_op or {}).get("responses",{}) or {}; new_resp=new_op.get("responses",{}) or {}
            for code in old_resp:
                if code not in new_resp: out.append(f"{opkey}: response removed: {code}")
    old_s=((old.get("components") or {}).get("schemas") or {}); new_s=((new.get("components") or {}).get("schemas") or {})
    for name,sch in old_s.items():
        if name not in new_s: out.append(f"schema removed: {name}")
        else: out.extend(_schema_changes(sch,new_s[name],f"schema {name}"))
    return out


DESTRUCTIVE_SQL_PATTERNS=[
    (re.compile(r"\bdrop\s+table\b",re.I),"DROP TABLE"),
    (re.compile(r"\bdrop\s+column\b",re.I),"DROP COLUMN"),
    (re.compile(r"\btruncate\b",re.I),"TRUNCATE"),
    (re.compile(r"\balter\s+table\b[\s\S]*?\balter\s+column\b[\s\S]*?\btype\b",re.I),"ALTER COLUMN TYPE"),
    (re.compile(r"\.dropTable\s*\(",re.I),"dropTable()"),
    (re.compile(r"\.dropColumn\s*\(",re.I),"dropColumn()"),
]


def destructive_migration_findings(text: str) -> list[str]:
    return [label for rx,label in DESTRUCTIVE_SQL_PATTERNS if rx.search(text)]
