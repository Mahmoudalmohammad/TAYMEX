from __future__ import annotations
from pathlib import Path
from .registries import load_settings, load_modules, load_component_catalog, load_permissions, load_events
from .repository_truth import load_api_contracts, build_repository_truth, symbol_keys, contract_operation_keys


def inspect_projects(repo: Path):
    projects = []
    ignored = {"node_modules", ".git", ".nx"}
    for p in repo.rglob("project.json"):
        if any(part in ignored for part in p.parts):
            continue
        projects.append({"path": str(p.relative_to(repo))})
    return projects


def _catalog(repo: Path, root: Path, cfg: dict):
    settings=load_settings(root,cfg); permissions=load_permissions(root,cfg); events=load_events(root,cfg)
    contracts=load_api_contracts(repo,root,cfg)
    modules=load_modules(repo,root,cfg,settings,permissions,events,contracts)
    truth=build_repository_truth(repo,root,cfg,modules,permissions,events,contracts,write=False)
    return settings,permissions,events,contracts,modules,truth


def inspect_module(repo: Path, root: Path, cfg: dict, module_id: str):
    settings,permissions,events,contracts,modules,truth=_catalog(repo,root,cfg)
    if module_id not in modules:
        return None
    data, path = modules[module_id]
    symbols=[x for x in truth.get('symbols',[]) if any(x.get('file','').startswith(sr.rstrip('/')+'/') for sr in data.get('sourceRoots',[]) or [])]
    models=[x for x in truth.get('dataModels',[]) if x.get('module')==module_id]
    return {"manifest": data, "path": str(path.relative_to(repo)), "symbols":symbols, "dataModels":models}


def inspect_settings(root: Path, cfg: dict, key: str | None = None):
    settings = load_settings(root, cfg)
    if key:
        return settings.get(key)
    return list(settings.values())


def inspect_permissions(root: Path,cfg:dict,key:str|None=None):
    items=load_permissions(root,cfg)
    return items.get(key) if key else list(items.values())


def inspect_events(root: Path,cfg:dict,key:str|None=None):
    items=load_events(root,cfg)
    return items.get(key) if key else list(items.values())


def inspect_contracts(repo:Path,root:Path,cfg:dict,key:str|None=None):
    items=load_api_contracts(repo,root,cfg)
    out=[]
    for cid,(m,p,doc,ops) in items.items():
        item=dict(m,manifestPath=str(p.relative_to(repo)),operations=ops)
        if key==cid or (key and any(op['operationId']==key for op in ops)): return item
        out.append(item)
    return None if key else out


def inspect_symbols(repo:Path,root:Path,cfg:dict,key:str|None=None):
    *_,truth=_catalog(repo,root,cfg)
    out=[]
    for s in truth.get('symbols',[]):
        if not key or s.get('name')==key or any(m.get('name')==key.split('.')[-1] for m in s.get('members',[]) if key.startswith(s.get('name','')+'.')):
            out.append(s)
    return out


def inspect_models(repo:Path,root:Path,cfg:dict,key:str|None=None):
    *_,truth=_catalog(repo,root,cfg)
    vals=truth.get('dataModels',[])
    if not key: return vals
    return [x for x in vals if key in {x.get('symbol'),x.get('table'),x.get('physicalName'),x.get('ownershipKey')}]


def inspect_components(repo: Path, root: Path | None = None, cfg: dict | None = None):
    if root is not None and cfg is not None:
        data=load_component_catalog(repo, root, cfg)
        out=[]
        for manifest,path in data.values():
            try:
                rel=str(path.relative_to(repo)); source='repository'
            except ValueError:
                rel=str(path.relative_to(root)); source='platform'
            out.append(dict(manifest, manifestPath=rel, source=source))
        return out
    ignored = {"node_modules", ".git", ".nx"}
    stories, manifests = [], []
    for p in repo.rglob("*"):
        if any(part in ignored for part in p.parts):
            continue
        name = p.name
        if p.is_file() and (".stories." in name):
            stories.append(str(p.relative_to(repo)))
        if p.is_file() and name in {"component.manifest.yaml", "component.manifest.yml", "component.manifest.json"}:
            manifests.append(str(p.relative_to(repo)))
    return {"stories": sorted(stories), "manifests": sorted(manifests)}
