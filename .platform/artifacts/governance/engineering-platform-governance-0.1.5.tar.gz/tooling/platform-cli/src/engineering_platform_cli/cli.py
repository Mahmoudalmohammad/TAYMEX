from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import yaml
from .root import find_root
from .io_utils import load_data
from .contracts import validate_document, ValidationFailure
from .registries import load_rules, load_settings, load_terminology, load_modules, load_components, load_component_catalog, load_permissions, load_events, RegistryFailure
from .git_utils import is_git_repo, revision_exists, changes
from .context import prepare_context
from .verify import verify_task
from .report import write_summary
from .inspectors import inspect_projects, inspect_module, inspect_settings, inspect_components, inspect_permissions, inspect_events, inspect_contracts, inspect_symbols, inspect_models
from .generate import generate_module, generate_ui_primitive, generate_admin_crud_page, generate_page_pattern
from .ui_checks import load_ui_policy, scan_ui_file
from .ui_verification import load_manifests, run_affected_ui_gates
from .risk import infer_minimum_risk, risk_index
from .themes import load_theme_profile, build_theme_profile, explain_theme, ThemeFailure
from .repository_truth import load_api_contracts, build_repository_truth, symbol_keys, contract_operation_keys
from .trust import load_trust_policy, verify_control_plane, extract_trusted_bundle
from .project_profiles import load_project_profile, find_project_profiles
from .consumer_boundary import verify_consumer_boundary
from .handoff import create_handoff, load_handoff, verify_handoff, collect_live_state


def _root_and_cfg(args):
    repo = Path(getattr(args, "repo", None) or Path.cwd()).resolve()
    root = find_root(repo if (repo / "tooling" / "governance.config.yaml").exists() else None)
    cfg = load_data(root / "tooling" / "governance.config.yaml")
    return repo, root, cfg


def cmd_validate(args):
    repo, root, cfg = _root_and_cfg(args)
    load_trust_policy(root, cfg)
    # Critical pre-slice policies are machine-validated so architectural intent
    # cannot silently drift into a different executable meaning.
    validate_document(root / cfg["policies"]["taskAuthority"], root / cfg["schemas"]["taskAuthorityPolicy"])
    validate_document(root / cfg["policies"]["artifactBoundary"], root / cfg["schemas"]["artifactBoundaryPolicy"])
    load_rules(root, cfg)
    settings = load_settings(root, cfg)
    permissions = load_permissions(root,cfg)
    events = load_events(root,cfg)
    load_terminology(root, cfg)
    contracts = load_api_contracts(repo,root,cfg)
    modules = load_modules(repo, root, cfg, settings, permissions, events, contracts)
    truth = build_repository_truth(repo,root,cfg,modules,permissions,events,contracts,write=True)
    components = load_component_catalog(repo, root, cfg)
    ui_manifests = load_manifests(repo, root, cfg)
    theme_examples=list((root / "blueprints" / "theme-profiles").glob("*.yaml")) if (root / "blueprints" / "theme-profiles").exists() else []
    project_profiles=find_project_profiles(root)
    for theme_path in theme_examples:
        load_theme_profile(theme_path, root, cfg)
    for profile_path in project_profiles:
        load_project_profile(profile_path, root, cfg)
    print(f"PASS: registries valid; {len(settings)} settings; {len(permissions)} permissions; {len(events)} events; {len(contracts)} API contracts; {len(modules)} module manifests; {len(truth.get('symbols',[]))} TS symbols; {len(truth.get('dataModels',[]))} data models; {len(components)} UI component manifests; {len(ui_manifests)} UI verification manifests; {len(theme_examples)} theme profiles; {len(project_profiles)} project profiles")
    return 0


def _load_task(task_path: Path, root: Path, cfg: dict):
    return validate_document(task_path, root / cfg["schemas"]["task"])


def cmd_task_prepare(args):
    repo, root, cfg = _root_and_cfg(args)
    task_path = Path(args.task).resolve()
    task = _load_task(task_path, root, cfg)
    rules = load_rules(root, cfg)
    for gate in task.get("requiredGates", []) or []:
        if gate not in rules:
            raise RegistryFailure(f"Task references unknown gate: {gate}")
        if rules[gate].get("implementationStatus") != "implemented":
            raise RegistryFailure(f"Task requires gate {gate}, but it is not executable yet ({rules[gate].get('implementationStatus','unknown')})")
    blocked = [a for a in task.get("assumptions", []) if a.get("status") != "verified"]
    if blocked:
        raise RegistryFailure("Task has blocked assumptions; preparation refused: " + "; ".join(a.get("statement", "") for a in blocked))
    settings = load_settings(root, cfg)
    permissions = load_permissions(root,cfg)
    events = load_events(root,cfg)
    contracts = load_api_contracts(repo,root,cfg)
    modules = load_modules(repo, root, cfg, settings, permissions, events, contracts)
    load_component_catalog(repo, root, cfg)
    truth = build_repository_truth(repo,root,cfg,modules,permissions,events,contracts,write=True)
    missing_modules = [m for m in task["modules"] if m not in modules]
    if missing_modules:
        raise RegistryFailure("Declared module manifests not found: " + ", ".join(missing_modules))
    obligations=task.get("obligations",{}) or {}
    missing_settings = [k for k in (obligations.get("settings", []) or []) if k not in settings]
    missing_permissions = [k for k in (obligations.get("permissions", []) or []) if k not in permissions]
    missing_events = [k for k in (obligations.get("events", []) or []) if k not in events]
    contract_keys=contract_operation_keys(truth)
    missing_contracts=[k for k in (obligations.get("contracts",[]) or []) if k not in contract_keys]
    symbol_index=symbol_keys(truth)
    missing_symbols=[k for k in (obligations.get("symbols",[]) or []) if k not in symbol_index]
    if missing_settings: raise RegistryFailure("PRE-001: task references unknown settings: " + ", ".join(missing_settings))
    if missing_permissions: raise RegistryFailure("PRE-001: task references unknown permissions: " + ", ".join(missing_permissions))
    if missing_events: raise RegistryFailure("PRE-001: task references unknown events: " + ", ".join(missing_events))
    if missing_contracts: raise RegistryFailure("PRE-001: task references unknown contracts/operations: " + ", ".join(missing_contracts))
    if missing_symbols: raise RegistryFailure("MODEL-001: task references unknown repository symbols: " + ", ".join(missing_symbols))
    min_risk, _ = infer_minimum_risk(task, [], cfg)
    if risk_index(cfg, task["risk"]) < risk_index(cfg, min_risk):
        raise RegistryFailure(f"Task risk {task['risk']} is below mode minimum {min_risk}")
    out = prepare_context(task, repo, root, cfg, truth_index=truth)
    print(f"PASS: context prepared at {out}")
    return 0


def cmd_task_verify(args):
    repo, root, cfg = _root_and_cfg(args)
    task_path = Path(args.task).resolve()
    task = _load_task(task_path, root, cfg)
    rules = load_rules(root, cfg)
    for gate in task.get("requiredGates", []) or []:
        if gate not in rules:
            raise RegistryFailure(f"GOV-001: unknown required gate: {gate}")
        if rules[gate].get("implementationStatus") != "implemented":
            raise RegistryFailure(f"GOV-001: required gate {gate} is not executable yet ({rules[gate].get('implementationStatus','unknown')})")
    settings = load_settings(root, cfg)
    permissions = load_permissions(root,cfg)
    events = load_events(root,cfg)
    contracts = load_api_contracts(repo,root,cfg)
    modules = load_modules(repo, root, cfg, settings, permissions, events, contracts)
    load_component_catalog(repo, root, cfg)
    truth = build_repository_truth(repo,root,cfg,modules,permissions,events,contracts,write=True)
    missing_modules = [m for m in task["modules"] if m not in modules]
    if missing_modules:
        raise RegistryFailure("Declared module manifests not found: " + ", ".join(missing_modules))
    obligations=task.get("obligations",{}) or {}
    missing_settings = [k for k in (obligations.get("settings", []) or []) if k not in settings]
    missing_permissions = [k for k in (obligations.get("permissions", []) or []) if k not in permissions]
    missing_events = [k for k in (obligations.get("events", []) or []) if k not in events]
    contract_keys=contract_operation_keys(truth)
    missing_contracts=[k for k in (obligations.get("contracts",[]) or []) if k not in contract_keys]
    symbol_index=symbol_keys(truth)
    missing_symbols=[k for k in (obligations.get("symbols",[]) or []) if k not in symbol_index]
    if missing_settings: raise RegistryFailure("PRE-001: task references unknown settings: " + ", ".join(missing_settings))
    if missing_permissions: raise RegistryFailure("PRE-001: task references unknown permissions: " + ", ".join(missing_permissions))
    if missing_events: raise RegistryFailure("PRE-001: task references unknown events: " + ", ".join(missing_events))
    if missing_contracts: raise RegistryFailure("PRE-001: task references unknown contracts/operations: " + ", ".join(missing_contracts))
    if missing_symbols: raise RegistryFailure("MODEL-001: task references unknown repository symbols: " + ", ".join(missing_symbols))
    if not is_git_repo(repo):
        raise RegistryFailure(f"Verification requires a git repository: {repo}")
    base = args.base or task["baseRevision"]
    if args.base and task["baseRevision"] != args.base:
        raise RegistryFailure(f"BASE-001: task baseRevision {task['baseRevision']} does not match trusted base {args.base}")
    if not revision_exists(repo, base):
        raise RegistryFailure(f"Base revision does not exist: {base}")
    task = dict(task)
    task["baseRevision"] = base
    ch = changes(repo, base, args.head)
    if any(c.path.startswith("packages/design-tokens/tokens/") for c in ch):
        import subprocess
        token_check = root / "packages" / "design-tokens" / "scripts" / "build_tokens.py"
        p = subprocess.run([sys.executable, str(token_check), "--check"], cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if p.returncode != 0:
            raise RegistryFailure("UI-009: design-token validation failed: " + (p.stderr.strip() or p.stdout.strip()))
    findings, metadata = verify_task(task, ch, repo, cfg, set(rules), root)
    ui_findings, ui_evidence = run_affected_ui_gates(repo, root, cfg, [c.path for c in ch], task.get("requiredGates", []) or [])
    findings.extend(ui_findings)
    if ui_evidence:
        metadata["uiVerification"] = ui_evidence
    out = write_summary(repo, cfg, task, metadata, findings)
    failed = any(f.severity == "blocking" for f in findings)
    print(f"{'FAIL' if failed else 'PASS'}: governance summary at {out}")
    for f in findings:
        print(f"- {f.rule}: {f.message}" + (f" [{f.path}]" if f.path else ""))
    return 1 if failed else 0


def cmd_inspect(args):
    repo, root, cfg = _root_and_cfg(args)
    if args.inspect_type == "projects":
        data = inspect_projects(repo)
    elif args.inspect_type == "module":
        data = inspect_module(repo, root, cfg, args.name)
    elif args.inspect_type == "settings":
        data = inspect_settings(root, cfg, args.name)
    elif args.inspect_type == "components":
        data = inspect_components(repo, root, cfg)
    elif args.inspect_type == "permissions":
        data = inspect_permissions(root,cfg,args.name)
    elif args.inspect_type == "events":
        data = inspect_events(root,cfg,args.name)
    elif args.inspect_type == "contracts":
        data = inspect_contracts(repo,root,cfg,args.name)
    elif args.inspect_type == "symbols":
        data = inspect_symbols(repo,root,cfg,args.name)
    elif args.inspect_type == "models":
        data = inspect_models(repo,root,cfg,args.name)
    else:
        raise RuntimeError("unsupported inspect type")
    print(json.dumps(data, indent=2, ensure_ascii=False))
    return 0



def cmd_truth_build(args):
    repo,root,cfg=_root_and_cfg(args)
    settings=load_settings(root,cfg); permissions=load_permissions(root,cfg); events=load_events(root,cfg)
    contracts=load_api_contracts(repo,root,cfg)
    modules=load_modules(repo,root,cfg,settings,permissions,events,contracts)
    truth=build_repository_truth(repo,root,cfg,modules,permissions,events,contracts,write=True)
    out=repo/cfg.get("repositoryTruth",{}).get("output",".governance/repository-truth.json")
    print(f"PASS: repository truth built at {out}; {len(truth.get('symbols',[]))} symbols; {len(truth.get('dataModels',[]))} data models; {len(truth.get('contracts',[]))} contracts")
    return 0


def cmd_generate(args):
    repo, root, cfg = _root_and_cfg(args)
    if args.generate_type == "module":
        target = generate_module(repo, args.name, args.layer, args.owner)
    elif args.generate_type == "ui-primitive":
        target = generate_ui_primitive(repo, args.name)
    elif args.generate_type == "admin-crud-page":
        target = generate_admin_crud_page(repo, args.name, args.target)
    else:
        target = generate_page_pattern(repo, args.name, args.target, args.generate_type.replace("-page", ""))
    print(f"PASS: generated {target}")
    return 0


def cmd_ui_doctor(args):
    repo, root, cfg = _root_and_cfg(args)
    import subprocess
    script = root / "tooling" / "ui-tests" / "doctor.py"
    return subprocess.run([sys.executable, str(script)], cwd=root).returncode


def cmd_ui_verify(args):
    repo, root, cfg = _root_and_cfg(args)
    manifests = load_manifests(repo, root, cfg)
    selected = [(d,p) for d,p in manifests if not args.manifest_id or d["id"] == args.manifest_id]
    if not selected:
        raise RuntimeError("No matching UI verification manifest")
    import subprocess
    runner = root / "tooling" / "ui-tests" / "run_manifest.py"
    failed = False
    for data, path in selected:
        cmd=[sys.executable,str(runner),str(path),"--repo",str(repo)]
        if args.update: cmd.append("--update")
        result=subprocess.run(cmd,cwd=root)
        failed = failed or result.returncode != 0
    return 1 if failed else 0


def cmd_ui_check(args):
    repo, root, cfg = _root_and_cfg(args)
    policy = load_ui_policy(root, cfg)
    paths=[]
    if args.paths:
        paths=[Path(x) for x in args.paths]
    else:
        for scan_root in policy.get("scanRoots", []):
            base=repo / scan_root
            if base.exists():
                paths.extend(p for p in base.rglob("*") if p.is_file())
    findings=[]
    for path in paths:
        try:
            rel=str(path.resolve().relative_to(repo)).replace("\\","/")
        except ValueError:
            rel=str(path).replace("\\","/")
        findings.extend(scan_ui_file(repo, rel, policy))
    if findings:
        print(f"FAIL: {len(findings)} UI governance finding(s)")
        for f in findings:
            print(f"- {f['rule']}: {f['message']} [{f['path']}]")
        return 1
    print("PASS: UI governance checks passed")
    return 0


def cmd_theme_validate(args):
    repo, root, cfg = _root_and_cfg(args)
    profile=Path(args.profile).resolve()
    data=load_theme_profile(profile,root,cfg)
    print(f"PASS: theme {data['id']} is valid")
    return 0


def cmd_theme_build(args):
    repo, root, cfg = _root_and_cfg(args)
    profile=Path(args.profile).resolve()
    out=Path(args.out).resolve() if args.out else None
    target=build_theme_profile(profile,root,cfg,out)
    print(f"PASS: generated governed theme CSS at {target}")
    return 0


def cmd_theme_explain(args):
    repo, root, cfg = _root_and_cfg(args)
    result=explain_theme(Path(args.profile).resolve(),root,cfg,args.key,args.mode)
    print(json.dumps(result,indent=2,ensure_ascii=False))
    return 0



def cmd_trust_verify_control_plane(args):
    repo, root, cfg = _root_and_cfg(args)
    findings, metadata = verify_control_plane(repo, root, cfg, args.base, args.head)
    failed = bool(findings)
    print(f"{'FAIL' if failed else 'PASS'}: trust-root control-plane verification")
    print(json.dumps(metadata, indent=2, ensure_ascii=False))
    for f in findings:
        print(f"- {f.rule}: {f.message}" + (f" [{f.path}]" if f.path else ""))
    return 1 if failed else 0


def cmd_trust_extract(args):
    repo, root, cfg = _root_and_cfg(args)
    out = Path(args.out).resolve()
    extract_trusted_bundle(repo, args.base, out)
    print(f"PASS: trusted verifier bundle extracted from {args.base} to {out}")
    return 0


def cmd_trust_validate(args):
    repo, root, cfg = _root_and_cfg(args)
    policy = load_trust_policy(root, cfg)
    print(f"PASS: trust-root policy valid; {len(policy.get('controlPlanePaths',[]))} control-plane patterns; {len(policy.get('trustRootPaths',[]))} trust-root patterns; {len(policy.get('proofAssetPaths',[]))} proof-asset patterns")
    return 0


def cmd_project_validate(args):
    repo, root, cfg = _root_and_cfg(args)
    path = Path(args.profile).resolve()
    data = load_project_profile(path, root, cfg)
    print(json.dumps({
        "status": "PASS",
        "project": data["project"]["id"],
        "consumerMode": data["project"]["consumerMode"],
        "runtime": data["runtime"],
        "locales": data["localization"],
        "enabledCapabilities": sorted(k for k,v in data.get("capabilities",{}).items() if v == "enabled"),
        "settingsScopes": data["settings"]["enabledScopes"],
    }, indent=2, ensure_ascii=False))
    return 0

def cmd_consumer_verify_boundary(args):
    repo = Path(getattr(args, "repo", None) or Path.cwd()).resolve()
    findings, metadata = verify_consumer_boundary(repo, Path(args.lock).resolve() if args.lock else None)
    if findings:
        print("FAIL: consumer artifact boundary verification")
        for finding in findings:
            where = f" [{finding.path}]" if finding.path else ""
            print(f"  {finding.rule}{where}: {finding.message}")
        return 2
    print(f"PASS: independent consumer boundary verified; {len(metadata['lockedArtifacts'])} locked platform artifacts; {sum(len(v) for v in metadata['usedPlatformDependencies'].values())} declared platform dependency uses")
    return 0



def cmd_handoff_status(args):
    repo, root, cfg = _root_and_cfg(args)
    state, checks = collect_live_state(repo, root, cfg, Path(args.platform_repo).resolve() if args.platform_repo else None)
    snapshot_path = repo / ".handoff" / "current.json"
    snapshot_status = "missing"
    if snapshot_path.exists():
        try:
            snap = load_handoff(repo, root, cfg)
            snapshot_status = snap.get("status", "unknown")
        except Exception as exc:
            snapshot_status = f"invalid: {exc}"
    print(json.dumps({"live": state, "snapshot": snapshot_status}, indent=2, ensure_ascii=False))
    return 0 if state.get("status") == "verified" else 1


def cmd_handoff_create(args):
    repo, root, cfg = _root_and_cfg(args)
    state, checks = create_handoff(repo, root, cfg, Path(args.platform_repo).resolve() if args.platform_repo else None)
    print(json.dumps(state, indent=2, ensure_ascii=False))
    print(f"{'PASS' if state['status'] == 'verified' else 'BLOCKED'}: handoff snapshot written to .handoff/current.json")
    return 0 if state["status"] == "verified" else 1


def cmd_handoff_verify(args):
    repo, root, cfg = _root_and_cfg(args)
    live, failures = verify_handoff(repo, root, cfg, Path(args.platform_repo).resolve() if args.platform_repo else None)
    if failures:
        print("FAIL: handoff verification")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("PASS: handoff snapshot matches live repository truth")
    print(json.dumps({
        "head": live["productRepository"]["head"],
        "branch": live["productRepository"]["branch"],
        "task": live["currentTask"]["id"],
        "foundation": live["foundation"]["readiness"],
        "platformSourceAvailable": live["platformRepository"]["availableLocally"],
    }, indent=2, ensure_ascii=False))
    return 0

def parser():
    p = argparse.ArgumentParser(prog="platform", description="Engineering Platform governance CLI")
    p.add_argument("--repo", help="Repository to inspect/verify (defaults to cwd)")
    sub = p.add_subparsers(dest="command", required=True)

    v = sub.add_parser("validate")
    v.set_defaults(func=cmd_validate)

    task = sub.add_parser("task")
    task_sub = task.add_subparsers(dest="task_command", required=True)
    prep = task_sub.add_parser("prepare")
    prep.add_argument("task")
    prep.set_defaults(func=cmd_task_prepare)
    ver = task_sub.add_parser("verify")
    ver.add_argument("task")
    ver.add_argument("--base")
    ver.add_argument("--head", default="HEAD")
    ver.set_defaults(func=cmd_task_verify)

    ins = sub.add_parser("inspect")
    ins_sub = ins.add_subparsers(dest="inspect_type", required=True)
    ip = ins_sub.add_parser("projects")
    ip.set_defaults(func=cmd_inspect)
    im = ins_sub.add_parser("module")
    im.add_argument("name")
    im.set_defaults(func=cmd_inspect)
    ise = ins_sub.add_parser("settings")
    ise.add_argument("name", nargs="?")
    ise.set_defaults(func=cmd_inspect)
    ic = ins_sub.add_parser("components")
    ic.set_defaults(func=cmd_inspect)
    for kind in ("permissions","events","contracts","symbols","models"):
        ix=ins_sub.add_parser(kind)
        ix.add_argument("name", nargs="?")
        ix.set_defaults(func=cmd_inspect)

    truth = sub.add_parser("truth")
    truth_sub=truth.add_subparsers(dest="truth_command",required=True)
    tbld=truth_sub.add_parser("build")
    tbld.set_defaults(func=cmd_truth_build)

    project = sub.add_parser("project")
    project_sub = project.add_subparsers(dest="project_command", required=True)
    pv = project_sub.add_parser("validate")
    pv.add_argument("profile")
    pv.set_defaults(func=cmd_project_validate)


    handoff = sub.add_parser("handoff")
    handoff_sub = handoff.add_subparsers(dest="handoff_command", required=True)
    hs = handoff_sub.add_parser("status")
    hs.add_argument("--platform-repo")
    hs.set_defaults(func=cmd_handoff_status)
    hc = handoff_sub.add_parser("create")
    hc.add_argument("--platform-repo")
    hc.set_defaults(func=cmd_handoff_create)
    hv = handoff_sub.add_parser("verify")
    hv.add_argument("--platform-repo")
    hv.set_defaults(func=cmd_handoff_verify)

    consumer = sub.add_parser("consumer")
    consumer_sub = consumer.add_subparsers(dest="consumer_command", required=True)
    cb = consumer_sub.add_parser("verify-boundary")
    cb.add_argument("--lock")
    cb.set_defaults(func=cmd_consumer_verify_boundary)

    trust = sub.add_parser("trust")
    trust_sub = trust.add_subparsers(dest="trust_command", required=True)
    tv = trust_sub.add_parser("validate")
    tv.set_defaults(func=cmd_trust_validate)
    tcp = trust_sub.add_parser("verify-control-plane")
    tcp.add_argument("--base", required=True)
    tcp.add_argument("--head", required=True)
    tcp.set_defaults(func=cmd_trust_verify_control_plane)
    te = trust_sub.add_parser("extract")
    te.add_argument("--base", required=True)
    te.add_argument("--out", required=True)
    te.set_defaults(func=cmd_trust_extract)

    ui = sub.add_parser("ui")
    ui_sub = ui.add_subparsers(dest="ui_command", required=True)
    uic = ui_sub.add_parser("check")
    uic.add_argument("paths", nargs="*")
    uic.set_defaults(func=cmd_ui_check)
    uiv = ui_sub.add_parser("verify")
    uiv.add_argument("--manifest-id")
    uiv.add_argument("--update", action="store_true")
    uiv.set_defaults(func=cmd_ui_verify)
    uid = ui_sub.add_parser("doctor")
    uid.set_defaults(func=cmd_ui_doctor)

    theme = sub.add_parser("theme")
    theme_sub = theme.add_subparsers(dest="theme_command", required=True)
    tv = theme_sub.add_parser("validate")
    tv.add_argument("profile")
    tv.set_defaults(func=cmd_theme_validate)
    tb = theme_sub.add_parser("build")
    tb.add_argument("profile")
    tb.add_argument("--out")
    tb.set_defaults(func=cmd_theme_build)
    te = theme_sub.add_parser("explain")
    te.add_argument("profile")
    te.add_argument("key")
    te.add_argument("--mode", choices=["light","dark"], default="light")
    te.set_defaults(func=cmd_theme_explain)

    gen = sub.add_parser("generate")
    gen_sub = gen.add_subparsers(dest="generate_type", required=True)
    gm = gen_sub.add_parser("module")
    gm.add_argument("name")
    gm.add_argument("--layer", choices=["kernel", "foundation", "capability", "domain"], required=True)
    gm.add_argument("--owner", required=True)
    gm.set_defaults(func=cmd_generate)
    gu = gen_sub.add_parser("ui-primitive")
    gu.add_argument("name")
    gu.set_defaults(func=cmd_generate)
    gp = gen_sub.add_parser("admin-crud-page")
    gp.add_argument("name")
    gp.add_argument("--target", required=True, help="Parent path under apps/ or examples/")
    gp.set_defaults(func=cmd_generate)
    for page_type in ("form-page", "settings-page", "search-page", "details-page"):
        gx = gen_sub.add_parser(page_type)
        gx.add_argument("name")
        gx.add_argument("--target", required=True, help="Parent path under apps/ or examples/")
        gx.set_defaults(func=cmd_generate)
    return p


def main(argv=None):
    try:
        args = parser().parse_args(argv)
        return args.func(args)
    except (ValidationFailure, RegistryFailure, ThemeFailure, RuntimeError, ValueError, yaml.YAMLError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2

if __name__ == "__main__":
    raise SystemExit(main())
