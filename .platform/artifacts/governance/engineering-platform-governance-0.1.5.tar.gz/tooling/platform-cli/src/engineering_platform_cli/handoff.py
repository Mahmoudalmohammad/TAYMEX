from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
from typing import Any

import yaml

from .contracts import validate_document, ValidationFailure
from .consumer_boundary import verify_consumer_boundary
from .project_profiles import find_project_profiles, load_project_profile


class HandoffFailure(RuntimeError):
    pass


@dataclass(frozen=True)
class LiveCheck:
    id: str
    passed: bool
    detail: str

    def as_dict(self) -> dict[str, Any]:
        return {"id": self.id, "passed": self.passed, "detail": self.detail}


def _git(repo: Path, *args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    p = subprocess.run(
        ["git", *args], cwd=repo, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE
    )
    if check and p.returncode != 0:
        raise HandoffFailure(p.stderr.strip() or f"git {' '.join(args)} failed")
    return p


def _git_metadata(repo: Path) -> dict[str, Any]:
    if _git(repo, "rev-parse", "--is-inside-work-tree", check=False).returncode != 0:
        raise HandoffFailure(f"HANDOFF-GIT-001: repository is not a git worktree: {repo}")
    head = _git(repo, "rev-parse", "HEAD").stdout.strip()
    branch = _git(repo, "branch", "--show-current").stdout.strip() or "DETACHED"
    porcelain = _git(repo, "status", "--porcelain=v1", "--untracked-files=all").stdout
    return {
        "name": repo.name,
        "branch": branch,
        "head": head,
        "clean": not bool(porcelain.strip()),
    }


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _current_task(repo: Path) -> dict[str, Any]:
    task_path = repo / ".governance" / "task.yaml"
    if not task_path.exists():
        return {"id": None, "status": "missing", "evidencePath": None, "passed": False}
    try:
        task = yaml.safe_load(task_path.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        return {"id": None, "status": "invalid", "evidencePath": None, "passed": False, "error": str(exc)}
    task_id = task.get("id")
    if not task_id:
        return {"id": None, "status": "invalid", "evidencePath": None, "passed": False}
    rel = Path(".governance") / "evidence" / str(task_id) / "governance-summary.json"
    evidence = repo / rel
    if not evidence.exists():
        return {"id": task_id, "status": "missing-evidence", "evidencePath": rel.as_posix(), "passed": False}
    try:
        summary = json.loads(evidence.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"id": task_id, "status": "invalid-evidence", "evidencePath": rel.as_posix(), "passed": False, "error": str(exc)}
    passed = bool(summary.get("passed")) and summary.get("taskId") == task_id
    return {
        "id": task_id,
        "status": "verified" if passed else "failed",
        "evidencePath": rel.as_posix(),
        "passed": passed,
    }


def _foundation_state(repo: Path, root: Path, cfg: dict) -> tuple[dict[str, Any], LiveCheck]:
    manifest_path = repo / "blueprints" / "foundation" / "foundation.manifest.yaml"
    if not manifest_path.exists():
        return ({"present": False, "currentStage": None, "readiness": "UNKNOWN", "remainingCapabilities": []}, LiveCheck("foundation-manifest", False, "foundation manifest is missing"))
    schema_rel = cfg.get("schemas", {}).get("foundationManifest")
    try:
        if schema_rel:
            data = validate_document(manifest_path, root / schema_rel)
        else:
            data = yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
            if data.get("schemaVersion") != 1 or not isinstance(data.get("capabilities"), list):
                raise ValidationFailure("foundation manifest requires schemaVersion=1 and capabilities[]")
    except Exception as exc:
        return ({"present": True, "currentStage": None, "readiness": "INVALID", "remainingCapabilities": []}, LiveCheck("foundation-manifest", False, f"invalid foundation manifest: {exc}"))

    foundation = data.get("foundation", {})
    order = foundation.get("maturityOrder") or []
    rank = {value: idx for idx, value in enumerate(order)}
    remaining: list[str] = []
    for cap in data.get("capabilities", []):
        if not cap.get("requiredBeforeFeatureExpansion"):
            continue
        current, target = cap.get("currentMaturity"), cap.get("exitMaturity")
        if current not in rank or target not in rank or rank[current] < rank[target]:
            remaining.append(str(cap.get("id", "unknown")))
    readiness = "READY" if not remaining else "BLOCKED"
    # Stage is deliberately advisory and derived from the first F-number mentioned in remaining text/IDs only when possible.
    current_stage = foundation.get("currentStage")
    return (
        {
            "present": True,
            "id": foundation.get("id"),
            "currentStage": current_stage,
            "readiness": readiness,
            "remainingCapabilities": remaining,
        },
        LiveCheck("foundation-manifest", True, f"valid; readiness={readiness}; remaining={len(remaining)}"),
    )


def _project_profile_state(repo: Path, root: Path, cfg: dict) -> tuple[dict[str, Any], LiveCheck]:
    candidates = find_project_profiles(repo)
    if not candidates:
        return ({"present": False}, LiveCheck("project-profile", False, "no project profile found"))
    if len(candidates) != 1:
        return ({"present": True, "count": len(candidates)}, LiveCheck("project-profile", False, f"expected exactly one consumer project profile; found {len(candidates)}"))
    try:
        data = load_project_profile(candidates[0], root, cfg)
    except Exception as exc:
        return ({"present": True, "path": candidates[0].relative_to(repo).as_posix()}, LiveCheck("project-profile", False, f"invalid project profile: {exc}"))
    return (
        {
            "present": True,
            "path": candidates[0].relative_to(repo).as_posix(),
            "project": data["project"]["id"],
            "consumerMode": data["project"]["consumerMode"],
        },
        LiveCheck("project-profile", True, f"valid project profile for {data['project']['id']}"),
    )


def _governance_artifact_state(repo: Path) -> tuple[dict[str, Any], LiveCheck]:
    lock_path = repo / ".platform" / "governance.lock.yaml"
    if not lock_path.exists():
        return ({"present": False}, LiveCheck("governance-artifact", False, "governance.lock.yaml is missing"))
    try:
        data = yaml.safe_load(lock_path.read_text(encoding="utf-8")) or {}
        item = data["artifact"]
        artifact = (repo / item["file"]).resolve()
        if not artifact.is_relative_to(repo.resolve()):
            raise HandoffFailure("governance artifact escapes repository")
        if not artifact.exists():
            raise HandoffFailure("governance artifact is missing")
        actual = _sha256(artifact)
        if actual != item.get("sha256"):
            raise HandoffFailure(f"governance artifact hash mismatch: expected {item.get('sha256')}, got {actual}")
        state = {"present": True, "version": item.get("version"), "file": item.get("file"), "sha256": actual}
        return state, LiveCheck("governance-artifact", True, f"locked governance artifact {item.get('version')} verified")
    except Exception as exc:
        return ({"present": True}, LiveCheck("governance-artifact", False, str(exc)))


def _runtime_artifact_state(repo: Path) -> tuple[dict[str, Any], LiveCheck]:
    try:
        findings, metadata = verify_consumer_boundary(repo)
    except Exception as exc:
        return ({"verified": False, "lockedArtifacts": []}, LiveCheck("runtime-artifacts", False, str(exc)))
    if findings:
        detail = "; ".join(f"{f.rule}:{f.message}" for f in findings[:5])
        return ({"verified": False, "lockedArtifacts": metadata.get("lockedArtifacts", [])}, LiveCheck("runtime-artifacts", False, detail))
    return (
        {"verified": True, "lockedArtifacts": metadata.get("lockedArtifacts", [])},
        LiveCheck("runtime-artifacts", True, f"{len(metadata.get('lockedArtifacts', []))} locked runtime artifacts verified"),
    )


_GEN_SOURCE_RE = re.compile(r"^// Source:\s*(.+?)\s*$", re.MULTILINE)
_GEN_SHA_RE = re.compile(r"^// Source-SHA256:\s*([0-9a-f]{64})\s*$", re.MULTILINE)


def _generated_artifact_state(repo: Path) -> tuple[dict[str, Any], LiveCheck]:
    checked: list[str] = []
    stale: list[str] = []
    scan_roots = [repo / "apps", repo / "packages", repo / "capabilities"]
    for base in scan_roots:
        if not base.exists():
            continue
        for path in sorted(base.rglob("*")):
            if not path.is_file() or path.suffix not in {".ts", ".tsx", ".js", ".mjs", ".cjs"}:
                continue
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            if "GENERATED FILE" not in text or "DO NOT EDIT" not in text:
                continue
            source_match = _GEN_SOURCE_RE.search(text)
            sha_match = _GEN_SHA_RE.search(text)
            if not source_match or not sha_match:
                # Generated files without a verifiable source digest are visible but cannot claim freshness.
                stale.append(path.relative_to(repo).as_posix() + " (missing Source-SHA256)")
                continue
            source = (repo / source_match.group(1).strip()).resolve()
            rel = path.relative_to(repo).as_posix()
            checked.append(rel)
            if not source.is_relative_to(repo.resolve()) or not source.exists() or _sha256(source) != sha_match.group(1):
                stale.append(rel)
    if stale:
        return ({"checked": checked, "stale": stale}, LiveCheck("generated-artifacts", False, f"{len(stale)} generated artifact(s) are stale/unverifiable"))
    return ({"checked": checked, "stale": []}, LiveCheck("generated-artifacts", True, f"{len(checked)} generated artifact(s) verified by source digest"))


def _platform_source_state(repo: Path, explicit: Path | None = None) -> dict[str, Any]:
    candidate = explicit.resolve() if explicit else (repo.parent / "ENGINEERING_PLATFORM").resolve()
    if not candidate.exists():
        return {"availableLocally": False, "path": None, "gitTracked": False, "head": None, "branch": None}
    git_meta = None
    try:
        git_meta = _git_metadata(candidate)
    except Exception:
        pass
    return {
        "availableLocally": True,
        "path": str(candidate),
        "gitTracked": bool(git_meta),
        "head": git_meta.get("head") if git_meta else None,
        "branch": git_meta.get("branch") if git_meta else None,
    }


def collect_live_state(repo: Path, root: Path, cfg: dict, platform_repo: Path | None = None) -> tuple[dict[str, Any], list[LiveCheck]]:
    repo_meta = _git_metadata(repo)
    task = _current_task(repo)
    foundation, foundation_check = _foundation_state(repo, root, cfg)
    profile, profile_check = _project_profile_state(repo, root, cfg)
    runtime, runtime_check = _runtime_artifact_state(repo)
    governance, governance_check = _governance_artifact_state(repo)
    generated, generated_check = _generated_artifact_state(repo)
    checks = [
        LiveCheck("git-clean", repo_meta["clean"], "working tree is clean" if repo_meta["clean"] else "working tree has tracked/untracked changes"),
        LiveCheck("task-evidence", bool(task.get("passed")), f"current task {task.get('id')} evidence is {task.get('status')}"),
        foundation_check,
        profile_check,
        runtime_check,
        governance_check,
        generated_check,
    ]
    blockers = [c.detail for c in checks if not c.passed]
    state = {
        "schemaVersion": 1,
        "generatedAt": datetime.now(timezone.utc).isoformat(),
        "productRepository": repo_meta,
        "platformRepository": _platform_source_state(repo, platform_repo),
        "currentTask": task,
        "foundation": foundation,
        "projectProfile": profile,
        "artifacts": {"runtime": runtime, "governance": governance},
        "generatedArtifacts": generated,
        "verification": {c.id: ("pass" if c.passed else "fail") for c in checks},
        "blockers": blockers,
        "status": "verified" if not blockers else "blocked",
    }
    return state, checks


def _snapshot_path(repo: Path) -> Path:
    return repo / ".handoff" / "current.json"


def create_handoff(repo: Path, root: Path, cfg: dict, platform_repo: Path | None = None) -> tuple[dict[str, Any], list[LiveCheck]]:
    state, checks = collect_live_state(repo, root, cfg, platform_repo)
    path = _snapshot_path(repo)
    path.parent.mkdir(parents=True, exist_ok=True)
    schema_rel = cfg.get("schemas", {}).get("handoff")
    if schema_rel:
        # Validate in-memory by writing first; snapshot is generated/ignored and never authoritative.
        path.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        validate_document(path, root / schema_rel)
    else:
        path.write_text(json.dumps(state, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return state, checks


def load_handoff(repo: Path, root: Path, cfg: dict) -> dict[str, Any]:
    path = _snapshot_path(repo)
    if not path.exists():
        raise HandoffFailure("HANDOFF-001: .handoff/current.json does not exist; run `platform handoff create`")
    schema_rel = cfg.get("schemas", {}).get("handoff")
    if schema_rel:
        return validate_document(path, root / schema_rel)
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise HandoffFailure(f"HANDOFF-001: invalid handoff snapshot: {exc}") from exc


def verify_handoff(repo: Path, root: Path, cfg: dict, platform_repo: Path | None = None) -> tuple[dict[str, Any], list[str]]:
    snapshot = load_handoff(repo, root, cfg)
    live, checks = collect_live_state(repo, root, cfg, platform_repo)
    failures: list[str] = []

    snap_repo = snapshot.get("productRepository", {})
    live_repo = live["productRepository"]
    if snap_repo.get("head") != live_repo.get("head"):
        failures.append(f"HANDOFF-STALE-001: snapshot HEAD {snap_repo.get('head')} != actual HEAD {live_repo.get('head')}")
    if snap_repo.get("branch") != live_repo.get("branch"):
        failures.append(f"HANDOFF-STALE-002: snapshot branch {snap_repo.get('branch')} != actual branch {live_repo.get('branch')}")
    if snapshot.get("status") == "verified" and not live_repo.get("clean"):
        failures.append("HANDOFF-GIT-002: verified snapshot requires a clean working tree")

    # Never trust stored PASS values. Recompute all live checks and fail from live truth.
    failures.extend(f"HANDOFF-CHECK-001: {check.id}: {check.detail}" for check in checks if not check.passed)

    snap_task = snapshot.get("currentTask", {})
    live_task = live.get("currentTask", {})
    if snap_task.get("id") != live_task.get("id") or snap_task.get("evidencePath") != live_task.get("evidencePath"):
        failures.append("HANDOFF-STALE-003: current task/evidence reference differs from snapshot")
    if snapshot.get("status") == "verified" and not live_task.get("passed"):
        failures.append("HANDOFF-EVIDENCE-001: snapshot claims verified but live task evidence is not PASS")

    # If platform source was recorded with a git HEAD and remains available, verify it. Its absence is not a failure.
    snap_platform = snapshot.get("platformRepository", {})
    live_platform = live.get("platformRepository", {})
    if snap_platform.get("gitTracked") and live_platform.get("availableLocally") and live_platform.get("gitTracked"):
        if snap_platform.get("head") != live_platform.get("head"):
            failures.append("HANDOFF-PLATFORM-001: adjacent platform repository HEAD differs from snapshot")

    if snapshot.get("status") != "verified":
        failures.append(f"HANDOFF-STATUS-001: snapshot status is {snapshot.get('status')}; a handoff is accepted only when verified")

    return live, failures
