from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import tarfile
from typing import Iterable

import yaml


@dataclass
class BoundaryFinding:
    rule: str
    message: str
    path: str | None = None

    def as_dict(self) -> dict:
        return {"rule": self.rule, "message": self.message, "path": self.path, "severity": "blocking"}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_yaml(path: Path) -> dict:
    if not path.exists():
        raise RuntimeError(f"ART-001: required artifact lock is missing: {path}")
    try:
        return yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception as exc:
        raise RuntimeError(f"ART-001: artifact lock cannot be parsed: {exc}") from exc


def _package_jsons(repo: Path) -> Iterable[Path]:
    for path in sorted(repo.rglob("package.json")):
        if any(part in {"node_modules", ".git", ".next", "dist", "build"} for part in path.relative_to(repo).parts):
            continue
        yield path


def _tgz_manifest(path: Path) -> dict:
    try:
        with tarfile.open(path, "r:gz") as tf:
            member = tf.getmember("package/package.json")
            raw = tf.extractfile(member)
            if raw is None:
                raise RuntimeError("missing package/package.json")
            return json.loads(raw.read().decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"ART-001: invalid npm artifact {path}: {exc}") from exc



def _locked_runtime_entries(repo: Path) -> list[dict]:
    lock = repo.resolve() / ".platform" / "runtime.lock.yaml"
    data = _load_yaml(lock)
    if data.get("consumerMode") != "independent-repository":
        raise RuntimeError("ART-001: consumerMode must be independent-repository")
    artifacts = data.get("artifacts", []) or []
    if not isinstance(artifacts, list):
        raise RuntimeError("ART-001: runtime artifact list is invalid")
    return artifacts


def _verified_locked_npm_artifact(repo: Path, item: dict) -> tuple[Path, dict]:
    repo = repo.resolve()
    name = item.get("name")
    version = item.get("version")
    rel_file = item.get("file")
    expected = item.get("sha256")
    if not name or not version or not rel_file or not expected:
        raise RuntimeError("ART-001: artifact entry requires name/version/file/sha256")
    artifact = (repo / rel_file).resolve()
    if not artifact.is_relative_to(repo):
        raise RuntimeError(f"ART-001: artifact path escapes consumer repository: {rel_file}")
    if not artifact.exists():
        raise RuntimeError(f"ART-001: locked runtime artifact is missing: {rel_file}")
    actual = _sha256(artifact)
    if actual != expected:
        raise RuntimeError(f"ART-002: artifact SHA-256 mismatch for {name}: expected {expected}, got {actual}")
    manifest = _tgz_manifest(artifact)
    if manifest.get("name") != name or manifest.get("version") != version:
        raise RuntimeError(
            f"ART-001: artifact identity mismatch: lock={name}@{version}, "
            f"package={manifest.get('name')}@{manifest.get('version')}"
        )
    return artifact, manifest


def read_locked_npm_member(repo: Path, package_name: str, member: str, *, required: bool = True) -> bytes | None:
    """Read one member from a SHA-verified runtime artifact.

    This is the only supported fallback for governance/runtime discovery when an
    independent consumer does not have ENGINEERING_PLATFORM source checked out.
    """
    normalized = member.lstrip("/")
    if normalized.startswith("../") or "/../" in normalized:
        raise RuntimeError("ART-001: artifact member path may not traverse")
    matches = [item for item in _locked_runtime_entries(repo) if item.get("name") == package_name]
    if len(matches) != 1:
        if required:
            raise RuntimeError(f"ART-001: expected exactly one locked artifact for {package_name}; found {len(matches)}")
        return None
    artifact, _manifest = _verified_locked_npm_artifact(repo, matches[0])
    member_name = f"package/{normalized}"
    try:
        with tarfile.open(artifact, "r:gz") as tf:
            try:
                info = tf.getmember(member_name)
            except KeyError:
                if required:
                    raise RuntimeError(f"ART-001: {package_name} artifact is missing {normalized}")
                return None
            if not info.isfile():
                raise RuntimeError(f"ART-001: {package_name} artifact member is not a regular file: {normalized}")
            raw = tf.extractfile(info)
            if raw is None:
                raise RuntimeError(f"ART-001: unable to read {package_name} artifact member: {normalized}")
            return raw.read()
    except RuntimeError:
        raise
    except Exception as exc:
        raise RuntimeError(f"ART-001: invalid npm artifact {artifact}: {exc}") from exc


def read_all_locked_npm_members(repo: Path, member: str) -> list[tuple[str, Path, bytes]]:
    """Return matching members from every verified runtime artifact.

    Every artifact in the lock is integrity/identity checked before it can
    contribute repository truth. Missing optional members are ignored.
    """
    normalized = member.lstrip("/")
    result: list[tuple[str, Path, bytes]] = []
    for item in _locked_runtime_entries(repo):
        artifact, _manifest = _verified_locked_npm_artifact(repo, item)
        member_name = f"package/{normalized}"
        with tarfile.open(artifact, "r:gz") as tf:
            try:
                info = tf.getmember(member_name)
            except KeyError:
                continue
            if not info.isfile():
                raise RuntimeError(f"ART-001: {item['name']} artifact member is not a regular file: {normalized}")
            raw = tf.extractfile(info)
            if raw is None:
                raise RuntimeError(f"ART-001: unable to read {item['name']} artifact member: {normalized}")
            result.append((item["name"], artifact, raw.read()))
    return result

def verify_consumer_boundary(repo: Path, lock_path: Path | None = None) -> tuple[list[BoundaryFinding], dict]:
    repo = repo.resolve()
    lock = (lock_path or (repo / ".platform" / "runtime.lock.yaml")).resolve()
    data = _load_yaml(lock)
    artifacts = data.get("artifacts", []) or []
    findings: list[BoundaryFinding] = []
    locked_by_name: dict[str, dict] = {}

    if data.get("consumerMode") != "independent-repository":
        findings.append(BoundaryFinding("ART-001", "consumerMode must be independent-repository", str(lock.relative_to(repo)) if lock.is_relative_to(repo) else str(lock)))

    for item in artifacts:
        name = item.get("name")
        version = item.get("version")
        rel_file = item.get("file")
        expected = item.get("sha256")
        if not name or not version or not rel_file or not expected:
            findings.append(BoundaryFinding("ART-001", "artifact entry requires name/version/file/sha256", str(lock)))
            continue
        locked_by_name[name] = item
        artifact = (repo / rel_file).resolve()
        if not artifact.is_relative_to(repo):
            findings.append(BoundaryFinding("ART-001", "artifact path escapes consumer repository", rel_file))
            continue
        if not artifact.exists():
            findings.append(BoundaryFinding("ART-001", "locked runtime artifact is missing", rel_file))
            continue
        actual = _sha256(artifact)
        if actual != expected:
            findings.append(BoundaryFinding("ART-002", f"artifact SHA-256 mismatch: expected {expected}, got {actual}", rel_file))
            continue
        try:
            manifest = _tgz_manifest(artifact)
        except RuntimeError as exc:
            findings.append(BoundaryFinding("ART-001", str(exc), rel_file))
            continue
        if manifest.get("name") != name or manifest.get("version") != version:
            findings.append(BoundaryFinding("ART-001", f"artifact identity mismatch: lock={name}@{version}, package={manifest.get('name')}@{manifest.get('version')}", rel_file))
        for group in ("dependencies", "devDependencies", "peerDependencies", "optionalDependencies"):
            for dep, spec in (manifest.get(group) or {}).items():
                if isinstance(spec, str) and (spec.startswith("workspace:") or spec.startswith("link:")):
                    findings.append(BoundaryFinding("ART-003", f"published artifact contains forbidden {spec.split(':',1)[0]} dependency {dep}: {spec}", rel_file))

    used_platform_deps: dict[str, list[str]] = {}
    for pkg in _package_jsons(repo):
        rel = pkg.relative_to(repo).as_posix()
        try:
            manifest = json.loads(pkg.read_text(encoding="utf-8"))
        except Exception as exc:
            findings.append(BoundaryFinding("ART-001", f"invalid package.json: {exc}", rel))
            continue
        for group in ("dependencies", "devDependencies", "peerDependencies", "optionalDependencies"):
            for dep, spec in (manifest.get(group) or {}).items():
                if not isinstance(spec, str):
                    continue
                if dep.startswith("@engineering-platform/") and (spec.startswith("workspace:") or spec.startswith("link:")):
                    findings.append(BoundaryFinding("ART-003", f"platform dependency may not use consumer workspace/source link {dep}: {spec}", rel))
                if spec.startswith("link:") and not dep.startswith("@engineering-platform/"):
                    target = (pkg.parent / spec[5:]).resolve()
                    if not target.is_relative_to(repo):
                        findings.append(BoundaryFinding("ART-003", f"consumer-local link dependency escapes repository {dep}: {spec}", rel))
                if "ENGINEERING_PLATFORM" in spec or "engineering_platform" in spec.lower() and (spec.startswith("file:") or spec.startswith("../") or spec.startswith("/")):
                    findings.append(BoundaryFinding("ART-003", f"consumer dependency points at platform source: {dep}: {spec}", rel))
                if dep.startswith("@engineering-platform/"):
                    used_platform_deps.setdefault(dep, []).append(rel)
                    locked = locked_by_name.get(dep)
                    if locked is None:
                        findings.append(BoundaryFinding("ART-001", f"platform dependency {dep} is not present in runtime.lock.yaml", rel))
                        continue
                    expected_spec = f"file:{locked['file']}"
                    # file: is resolved relative to the package manifest, so compare normalized paths.
                    if spec.startswith("file:"):
                        resolved = (pkg.parent / spec[5:]).resolve()
                        expected_resolved = (repo / locked["file"]).resolve()
                        if resolved != expected_resolved:
                            findings.append(BoundaryFinding("ART-003", f"platform dependency {dep} does not resolve to locked artifact {locked['file']}", rel))
                    else:
                        findings.append(BoundaryFinding("ART-003", f"bootstrap consumer must use locked file: artifact for {dep}; got {spec}", rel))

    # Symlinks can silently recreate source-link coupling even when package.json looks clean.
    for path in sorted(repo.rglob("*")):
        if not path.is_symlink():
            continue
        target = path.resolve()
        if not target.is_relative_to(repo):
            findings.append(BoundaryFinding("ART-003", f"symlink escapes consumer repository to {target}", path.relative_to(repo).as_posix()))

    metadata = {
        "lock": str(lock),
        "lockedArtifacts": sorted(locked_by_name),
        "usedPlatformDependencies": used_platform_deps,
    }
    return findings, metadata
