from __future__ import annotations
from pathlib import Path
from .io_utils import dump_json, dump_text
from .registries import load_settings, load_modules, load_component_catalog, load_permissions, load_events
from .repository_truth import load_api_contracts, build_repository_truth, symbol_keys, contract_operation_keys
from .risk import infer_minimum_risk
from .themes import load_base_token_themes, ThemeFailure


def prepare_context(task: dict, repo: Path, root: Path, cfg: dict, truth_index: dict | None = None) -> Path:
    out = repo / cfg.get("contextDirectory", ".agent-context") / task["id"]
    settings = load_settings(root, cfg)
    permissions = load_permissions(root,cfg)
    events = load_events(root,cfg)
    contracts = load_api_contracts(repo,root,cfg)
    modules = load_modules(repo, root, cfg, settings, permissions, events, contracts)
    components = load_component_catalog(repo, root, cfg)
    truth_index = truth_index or build_repository_truth(repo,root,cfg,modules,permissions,events,contracts,write=True)

    task_modules = {}
    missing_modules = []
    source_roots=[]
    for mid in task["modules"]:
        if mid in modules:
            data, path = modules[mid]
            task_modules[mid] = {"manifest": data, "path": str(path.relative_to(repo))}
            source_roots.extend(data.get("sourceRoots",[]) or [])
        else:
            missing_modules.append(mid)

    relevant_settings = {key: settings.get(key) for key in task.get("obligations", {}).get("settings", []) or []}
    relevant_permissions = {key: permissions.get(key) for key in task.get("obligations", {}).get("permissions", []) or []}
    relevant_events = {key: events.get(key) for key in task.get("obligations", {}).get("events", []) or []}
    required_contracts=task.get("obligations", {}).get("contracts", []) or []
    relevant_contracts=[]
    for c in truth_index.get('contracts',[]):
        if c['id'] in required_contracts or any(k.startswith(c['id']+'#') for k in required_contracts):
            relevant_contracts.append(c)

    required_symbols=task.get("obligations",{}).get("symbols",[]) or []
    relevant_symbols=[]
    for s in truth_index.get('symbols',[]):
        if s.get('name') in required_symbols or any(f"{s.get('name')}.{m.get('name')}" in required_symbols for m in s.get('members',[])):
            relevant_symbols.append(s)
    # Also include symbols/data owned by declared modules so the agent can inspect real signatures without broad repository noise.
    module_symbols=[s for s in truth_index.get('symbols',[]) if any(s.get('file','').startswith(sr.rstrip('/')+'/') for sr in source_roots)]
    module_data=[d for d in truth_index.get('dataModels',[]) if d.get('module') in task['modules']]

    ui_components = [
        {"id": data["id"], "name": data["name"], "category": data["category"], "package": data["package"], "export": data["export"], "canonicalRoles": data.get("canonicalRoles", []), "status": data["status"]}
        for data, _path in components.values()
    ]
    semantic_tokens=[]
    try:
        token_themes = load_base_token_themes(root)
        semantic_tokens=sorted(k for k in token_themes.get("light",{}) if k.startswith("semantic."))
    except ThemeFailure:
        # Context preparation can still report the missing truth through the
        # normal validation path; it must never invent token names.
        semantic_tokens=[]

    minimum_risk, reasons = infer_minimum_risk(task, [], cfg)
    truth = {
        "taskId": task["id"],
        "declaredRisk": task["risk"],
        "minimumRiskFromMode": minimum_risk,
        "riskReasons": reasons,
        "modules": task_modules,
        "missingModules": missing_modules,
        "relevantSettings": relevant_settings,
        "relevantPermissions": relevant_permissions,
        "relevantEvents": relevant_events,
        "relevantContracts": relevant_contracts,
        "requiredSymbols": required_symbols,
        "relevantSymbols": relevant_symbols,
        "moduleSymbols": module_symbols,
        "moduleDataModels": module_data,
        "uiComponents": ui_components,
        "semanticDesignTokens": semantic_tokens,
        "allowedPaths": task["scope"]["allowedPaths"],
        "forbiddenPaths": task["scope"]["forbiddenPaths"],
        "repositoryTruthIndex": str((repo/cfg.get('repositoryTruth',{}).get('output','.governance/repository-truth.json')).relative_to(repo))
    }
    dump_json(out / "TASK.json", task)
    dump_json(out / "REPOSITORY_TRUTH.json", truth)
    dump_text(out / "ALLOWED_PATHS.txt", "\n".join(task["scope"]["allowedPaths"]))
    summary = [
        f"# Agent Context — {task['id']}", "",
        f"**Objective:** {task['objective']}", f"**Mode:** {task['mode']}", f"**Declared risk:** {task['risk']}", f"**Minimum risk from mode:** {minimum_risk}", "",
        "## Execution invariants", "",
        "- Do not guess repository facts. Use the generated Repository Truth index or platform inspect commands.",
        "- Do not invent model fields, method signatures, routes, permissions, events, settings, or API response shapes.",
        "- Do not hand-edit generated OpenAPI or generated API clients.",
        "- Do not query another module's owned tables or import its private data schema directly.",
        "- Do not change files outside allowedPaths.",
        "- Do not create files/dependencies/migrations/contracts/platform changes unless the task explicitly allows them.",
        "- Do not lower security, settings, architecture, UI, or performance standards to make the task pass.",
        "- For UI work, inspect REPOSITORY_TRUTH.uiComponents and semanticDesignTokens before creating or styling anything.",
        "- A fix must address the root cause at the correct abstraction and avoid unrelated cleanup/refactoring.", "",
        "## Missing repository truth", ""
    ]
    if missing_modules:
        summary.extend([f"- Missing module manifest: `{x}`" for x in missing_modules])
    else:
        summary.append("- None detected for declared modules.")
    dump_text(out / "SUMMARY.md", "\n".join(summary))
    return out
